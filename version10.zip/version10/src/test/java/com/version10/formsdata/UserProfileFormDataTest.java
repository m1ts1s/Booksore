package com.version10.formsdata;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class UserProfileFormDataTest {

    private UserProfileFormData userProfileFormData;
    private List<String> favouriteBookAuthors;
    private List<String> favouriteBookCategories;
    private List<String> bookOffers;
    private List<String> notifications;

    @BeforeEach
    public void setUp() {
        // Initialize data
        favouriteBookAuthors = new ArrayList<>();
        favouriteBookAuthors.add("Author 1");
        favouriteBookAuthors.add("Author 2");

        favouriteBookCategories = new ArrayList<>();
        favouriteBookCategories.add("Category 1");
        favouriteBookCategories.add("Category 2");

        bookOffers = new ArrayList<>();
        bookOffers.add("Book 1");
        bookOffers.add("Book 2");

        notifications = new ArrayList<>();
        notifications.add("Notification 1");
        notifications.add("Notification 2");

        // Initialize UserProfileFormData object
        userProfileFormData = new UserProfileFormData();
        userProfileFormData.setUsername("testuser");
        userProfileFormData.setFullName("Test User");
        userProfileFormData.setAge(30);
        userProfileFormData.setFavouriteBookAuthors(favouriteBookAuthors);
        userProfileFormData.setFavouriteBookCategories(favouriteBookCategories);
        userProfileFormData.setBookOffers(bookOffers);
        userProfileFormData.setAddress("123 Test St");
        userProfileFormData.setPhoneNumber("123-456-7890");
        userProfileFormData.setNotifications(notifications);
    }

    @Test
    public void testGettersAndSetters() {
        // Verify getters
        assertEquals("testuser", userProfileFormData.getUsername());
        assertEquals("Test User", userProfileFormData.getFullName());
        assertEquals(30, userProfileFormData.getAge());
        assertEquals(favouriteBookAuthors, userProfileFormData.getFavouriteBookAuthors());
        assertEquals(favouriteBookCategories, userProfileFormData.getFavouriteBookCategories());
        assertEquals(bookOffers, userProfileFormData.getBookOffers());
        assertEquals("123 Test St", userProfileFormData.getAddress());
        assertEquals("123-456-7890", userProfileFormData.getPhoneNumber());
        assertEquals(notifications, userProfileFormData.getNotifications());
    }

    @Test
    public void testDefaultConstructor() {
        // Create a new UserProfileFormData object using the default constructor
        UserProfileFormData userProfileFormData = new UserProfileFormData();

        // Verify the object is not null
        assertNotNull(userProfileFormData);
    }
}
