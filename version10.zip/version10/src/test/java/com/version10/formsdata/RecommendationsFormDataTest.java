package com.version10.formsdata;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class RecommendationsFormDataTest {

    private RecommendationsFormData recommendationsFormData;
    private List<String> categories;
    private List<String> authors;

    @BeforeEach
    public void setUp() {
        // Initialize data
        categories = new ArrayList<>();
        categories.add("Category 1");
        categories.add("Category 2");

        authors = new ArrayList<>();
        authors.add("Author 1");
        authors.add("Author 2");

        // Initialize RecommendationsFormData object
        recommendationsFormData = new RecommendationsFormData();
        recommendationsFormData.setRecommendationType(RecommendationsFormData.RecommendationType.BOTH);
        recommendationsFormData.setCategories(categories);
        recommendationsFormData.setAuthors(authors);
    }

    @Test
    public void testGettersAndSetters() {
        // Verify getters
        assertEquals(RecommendationsFormData.RecommendationType.BOTH, recommendationsFormData.getRecommendationType());
        assertEquals(categories, recommendationsFormData.getCategories());
        assertEquals(authors, recommendationsFormData.getAuthors());
    }

    @Test
    public void testDefaultConstructor() {
        // Create a new RecommendationsFormData object using the default constructor
        RecommendationsFormData recommendationsFormData = new RecommendationsFormData();

        // Verify the object is not null
        assertNotNull(recommendationsFormData);
    }
}
