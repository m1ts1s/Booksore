package com.version10.formsdata;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class BookFormDataTest {

    private BookFormData bookFormData;
    private List<String> authors;
    private List<String> requestingUsers;

    @BeforeEach
    public void setUp() {
        // Initialize data
        authors = new ArrayList<>();
        authors.add("Author 1");
        authors.add("Author 2");

        requestingUsers = new ArrayList<>();
        requestingUsers.add("user1");
        requestingUsers.add("user2");

        // Initialize BookFormData object
        bookFormData = new BookFormData();
        bookFormData.setBookId(1);
        bookFormData.setTitle("Test Book");
        bookFormData.setBookAuthors(authors);
        bookFormData.setBookCategory("Fiction");
        bookFormData.setSummary("This is a test book");
        bookFormData.setRequestingUsers(requestingUsers);
        bookFormData.setUserProfile("testuser");
    }

    @Test
    public void testGettersAndSetters() {
        // Verify getters
        assertEquals(1, bookFormData.getBookId());
        assertEquals("Test Book", bookFormData.getTitle());
        assertEquals(authors, bookFormData.getBookAuthors());
        assertEquals("Fiction", bookFormData.getBookCategory());
        assertEquals("This is a test book", bookFormData.getSummary());
        assertEquals(requestingUsers, bookFormData.getRequestingUsers());
        assertEquals("testuser", bookFormData.getUserProfile());
    }


    @Test
    public void testDefaultConstructor() {
        // Create a new BookFormData object using the default constructor
        BookFormData bookFormData = new BookFormData();

        // Verify the object is not null
        assertNotNull(bookFormData);
    }
}
