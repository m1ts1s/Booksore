package com.version10.formsdata;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class SearchFormDataTest {

    private SearchFormData searchFormData;

    @BeforeEach
    public void setUp() {
        // Initialize SearchFormData object
        searchFormData = new SearchFormData();
        searchFormData.setQueryTitle("Test Title");
        searchFormData.setQueryAuthor("Test Author");
        searchFormData.setExactSearch(true);
    }

    @Test
    public void testGettersAndSetters() {
        // Verify getters
        assertEquals("Test Title", searchFormData.getQueryTitle());
        assertEquals("Test Author", searchFormData.getQueryAuthor());
        assertTrue(searchFormData.isExactSearch());
    }


    @Test
    public void testDefaultConstructor() {
        // Create a new SearchFormData object using the default constructor
        SearchFormData searchFormData = new SearchFormData();

        // Verify the object is not null
        assertNotNull(searchFormData);
    }
}
