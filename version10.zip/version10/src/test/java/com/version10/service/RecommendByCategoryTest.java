package com.version10.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

import com.version10.dao.BookDAO;
import com.version10.domain.Book;
import com.version10.domain.BookCategory;
import com.version10.formsdata.RecommendationsFormData;
import com.version10.service.RecommendByCategory;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@ExtendWith(MockitoExtension.class)
public class RecommendByCategoryTest {

    @Mock
    private BookDAO bookDAO;

    @InjectMocks
    private RecommendByCategory recommendByCategory;

    private Book book1;
    private Book book2;
    private BookCategory category1;
    private BookCategory category2;
    private RecommendationsFormData recommendationsFormData;

    @BeforeEach
    public void setUp() {
        category1 = new BookCategory();
        category1.setName("Category One");

        category2 = new BookCategory();
        category2.setName("Category Two");

        book1 = new Book();
        book1.setTitle("Book One");
        book1.setBookCategory(category1);

        book2 = new Book();
        book2.setTitle("Book Two");
        book2.setBookCategory(category2);

        recommendationsFormData = new RecommendationsFormData();
        recommendationsFormData.setCategories(Collections.singletonList("Category One"));
    }

    @Test
    public void testMakeRecommendations() {
        List<Book> allBooks = Arrays.asList(book1, book2);

        when(bookDAO.findAll()).thenReturn(allBooks);

        List<Book> results = recommendByCategory.makeRecommendations(recommendationsFormData);

        assertEquals(1, results.size());
        assertEquals("Book One", results.get(0).getTitle());
    }

    @Test
    public void testMakeRecommendationsNoMatchingCategories() {
        List<Book> allBooks = Arrays.asList(book2);

        when(bookDAO.findAll()).thenReturn(allBooks);

        List<Book> results = recommendByCategory.makeRecommendations(recommendationsFormData);

        assertEquals(0, results.size());
    }
}
