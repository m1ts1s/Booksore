package com.version10.service;

import com.version10.dao.BookDAO;
import com.version10.domain.Book;
import com.version10.domain.BookAuthor;
import com.version10.formsdata.SearchFormData;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.mockito.Mockito.when;

public class ExactSearchStrategyTest {
    @Mock
    private BookDAO bookDAO;

    @InjectMocks
    private ExactSearchStrategy exactSearchStrategy;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testMakeInitialListOfBooks() {
        // Prepare data
        SearchFormData formData = new SearchFormData();
        formData.setQueryTitle("Test Title");
        formData.setQueryAuthor("Author1,Author2");

        BookAuthor author1 = new BookAuthor();
        author1.setName("Author1");
        BookAuthor author2 = new BookAuthor();
        author2.setName("Author2");
        List<BookAuthor> authors = new ArrayList<>();
        authors.add(author1);
        authors.add(author2);
        Book book = new Book();
        book.setTitle("Test Title");
        book.setBookAuthors(authors);
        bookDAO.save(book);

        // Mock behavior
        when(bookDAO.findByTitle("Test Title")).thenReturn(Optional.of(List.of(book)));

        // Test the method
        List<Book> result = exactSearchStrategy.makeInitialListOfBooks(formData);

        // Verify the result
        assertEquals(true,exactSearchStrategy.checkIfAuthorMatch(formData,book));
        assertEquals(1, result.size());
        assertEquals("Test Title", result.get(0).getTitle());
    }

    @Test
    public void testMissingAuthor() {
        // Prepare data
        SearchFormData formData = new SearchFormData();
        formData.setQueryTitle("Test Title");
        formData.setQueryAuthor("Author1");

        BookAuthor author1 = new BookAuthor();
        author1.setName("Author1");
        BookAuthor author2 = new BookAuthor();
        author2.setName("Author2");
        List<BookAuthor> authors = new ArrayList<>();
        authors.add(author1);
        authors.add(author2);
        Book book = new Book();
        book.setTitle("Test Title");
        book.setBookAuthors(authors);
        bookDAO.save(book);

        // Mock behavior
        when(bookDAO.findByTitle("Test Title")).thenReturn(Optional.of(List.of(book)));

        // Test the method
        List<Book> result = exactSearchStrategy.makeInitialListOfBooks(formData);

        // Verify the result
        assertEquals(false,exactSearchStrategy.checkIfAuthorMatch(formData,book));
        assertEquals(0, result.size());
    }

    @Test
    public void testMissingTitle() {
        // Prepare data
        SearchFormData formData = new SearchFormData();
        formData.setQueryTitle("Title");
        formData.setQueryAuthor("Author1,Author2");

        BookAuthor author1 = new BookAuthor();
        author1.setName("Author1");
        BookAuthor author2 = new BookAuthor();
        author2.setName("Author2");
        List<BookAuthor> authors = new ArrayList<>();
        authors.add(author1);
        authors.add(author2);
        Book book = new Book();
        book.setTitle("Test Title");
        book.setBookAuthors(authors);
        bookDAO.save(book);

        // Mock behavior
        when(bookDAO.findByTitle("Test Title")).thenReturn(Optional.of(List.of(book)));

        // Test the method
        List<Book> result = exactSearchStrategy.makeInitialListOfBooks(formData);

        // Verify the result
        assertEquals(true,exactSearchStrategy.checkIfAuthorMatch(formData,book));
        assertEquals(0, result.size());
    }
}
