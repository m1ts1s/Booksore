package com.version10.service;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

import com.version10.dao.BookDAO;
import com.version10.domain.Book;
import com.version10.domain.BookAuthor;
import com.version10.domain.BookCategory;
import com.version10.formsdata.RecommendationsFormData;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@ExtendWith(MockitoExtension.class)
public class RecommendMixedTest {

    @Mock
    private BookDAO bookDAO;

    @InjectMocks
    private RecommendMixed recommendMixed;

    private Book book1;
    private Book book2;
    private Book book3;
    private BookCategory category1;
    private BookCategory category2;
    private BookAuthor author1;
    private BookAuthor author2;
    private RecommendationsFormData recommendationsFormData;

    @BeforeEach
    public void setUp() {
        // Setup categories
        category1 = new BookCategory();
        category1.setName("Category One");

        category2 = new BookCategory();
        category2.setName("Category Two");

        // Setup authors
        author1 = new BookAuthor();
        author1.setName("Author One");

        author2 = new BookAuthor();
        author2.setName("Author Two");

        // Setup books
        book1 = new Book();
        book1.setTitle("Book One");
        book1.setBookCategory(category1);
        book1.setBookAuthors(Arrays.asList(author1, author2));

        book2 = new Book();
        book2.setTitle("Book Two");
        book2.setBookCategory(category2);
        book2.setBookAuthors(Collections.singletonList(author1));

        book3 = new Book();
        book3.setTitle("Book Three");
        book3.setBookCategory(category1);
        book3.setBookAuthors(Collections.singletonList(author2));

        // Setup recommendations form data
        recommendationsFormData = new RecommendationsFormData();
        recommendationsFormData.setAuthors(Collections.singletonList("Author One"));
        recommendationsFormData.setCategories(Collections.singletonList("Category One"));
    }

    @Test
    public void testMakeRecommendations() {
        List<Book> allBooks = Arrays.asList(book1, book2, book3);

        when(bookDAO.findAll()).thenReturn(allBooks);

        List<Book> results = recommendMixed.makeRecommendations(recommendationsFormData);

        assertEquals(1, results.size());
        assertEquals("Book One", results.get(0).getTitle());
    }
}
