package com.version10.service;

import com.version10.dao.BookDAO;
import com.version10.domain.Book;
import com.version10.domain.BookAuthor;
import com.version10.formsdata.SearchFormData;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

public class ApproximateSearchStrategyTest {

    @Mock
    private BookDAO bookDAO;

    @InjectMocks
    private ApproximateSearchStrategy approximateSearchStrategy;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    //Test the approximate works with part of the Title and only one of the Authors
    @Test
    public void testMakeInitialListOfBooks() {
        // Prepare data
        SearchFormData formData = new SearchFormData();
        formData.setQueryTitle("Title");
        formData.setQueryAuthor("Author1");

        BookAuthor author1 = new BookAuthor();
        author1.setName("Author1");
        BookAuthor author2 = new BookAuthor();
        author2.setName("Author2");
        List<BookAuthor> authors = new ArrayList<>();
        authors.add(author1);
        authors.add(author2);
        Book book = new Book();
        book.setTitle("Test Title");
        book.setBookAuthors(authors);
        bookDAO.save(book);

        // Mock behavior
        when(bookDAO.findByTitleContaining("Title")).thenReturn(Optional.of(List.of(book)));

        // Test the method
        List<Book> result = approximateSearchStrategy.makeInitialListOfBooks(formData);

        // Verify the result
        assertEquals(true,approximateSearchStrategy.checkIfAuthorMatch(formData,book));
        assertEquals(1, result.size());
        assertEquals("Test Title", result.get(0).getTitle());
    }
}
