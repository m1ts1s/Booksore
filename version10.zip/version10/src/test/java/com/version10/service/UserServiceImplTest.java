package com.version10.service;

import com.version10.dao.UserDAO;
import com.version10.domain.Role;
import com.version10.domain.User;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class UserServiceImplTest {

    @Mock
    private UserDAO userDAO;

    @Mock
    private BCryptPasswordEncoder bCryptPasswordEncoder;

    @InjectMocks
    private UserServiceImpl userService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testSaveUser() {
        // Mock behavior
        when(bCryptPasswordEncoder.encode(any())).thenReturn("encodedPassword");

        // Test the method
        userService.saveUser(new User(1, "testuser", "password", Role.USER));

        // Verify that save is called
        verify(userDAO, times(1)).save(any());
    }

    @Test
    public void testFindByUsername() {
        // Mock behavior
        when(userDAO.findByUsername("testuser")).thenReturn(Optional.of(new User(1, "testuser", "password", Role.USER)));

        // Test the method
        User user = userService.findByUsername("testuser");

        // Verify the result
        assertNotNull(user);
        assertEquals("testuser", user.getUsername());
    }

    @Test
    public void testLoadUserByUsername() {
        // Mock behavior
        when(userDAO.findByUsername("testuser")).thenReturn(Optional.of(new User(1, "testuser", "password", Role.USER)));

        // Test the method
        UserDetails userDetails = userService.loadUserByUsername("testuser");

        // Verify the result
        assertNotNull(userDetails);
        assertEquals("testuser", userDetails.getUsername());
    }

    @Test
    public void testLoadUserByUsernameNotFound() {
        // Mock behavior
        when(userDAO.findByUsername("nonexistinguser")).thenReturn(Optional.empty());

        // Test the method
        assertThrows(UsernameNotFoundException.class, () -> userService.loadUserByUsername("nonexistinguser"));

        // Verify that findByUsername is called
        verify(userDAO, times(1)).findByUsername("nonexistinguser");
    }
}
