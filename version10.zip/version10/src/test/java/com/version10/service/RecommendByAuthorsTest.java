package com.version10.service;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

import com.version10.dao.BookDAO;
import com.version10.domain.Book;
import com.version10.domain.BookAuthor;
import com.version10.formsdata.RecommendationsFormData;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@ExtendWith(MockitoExtension.class)
public class RecommendByAuthorsTest {

    @Mock
    private BookDAO bookDAO;

    @InjectMocks
    private RecommendByAuthors recommendByAuthors;

    private Book book1;
    private Book book2;
    private BookAuthor author1;
    private BookAuthor author2;
    private RecommendationsFormData recommendationsFormData;

    @BeforeEach
    public void setUp() {
        author1 = new BookAuthor();
        author1.setName("Author One");

        author2 = new BookAuthor();
        author2.setName("Author Two");

        book1 = new Book();
        book1.setTitle("Book One");
        book1.setBookAuthors(Collections.singletonList(author1));

        book2 = new Book();
        book2.setTitle("Book Two");
        book2.setBookAuthors(Collections.singletonList(author2));

        recommendationsFormData = new RecommendationsFormData();
        recommendationsFormData.setAuthors(Collections.singletonList("Author One"));
    }

    @Test
    public void testMakeRecommendations() {
        List<Book> allBooks = new ArrayList<>();
        allBooks.add(book1);
        allBooks.add(book2);

        when(bookDAO.findAll()).thenReturn(allBooks);

        List<Book> results = recommendByAuthors.makeRecommendations(recommendationsFormData);

        assertEquals(1, results.size());
        assertEquals("Book One", results.get(0).getTitle());
    }

    @Test
    public void testMakeRecommendationsNoMatchingAuthors() {
        List<Book> allBooks = new ArrayList<>();
        allBooks.add(book2);

        when(bookDAO.findAll()).thenReturn(allBooks);

        List<Book> results = recommendByAuthors.makeRecommendations(recommendationsFormData);

        assertEquals(0, results.size());
    }
}
