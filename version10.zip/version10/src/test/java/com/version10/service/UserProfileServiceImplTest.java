package com.version10.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.version10.dao.*;
import com.version10.domain.*;
import com.version10.exception.SelfBookRequestException;
import com.version10.formsdata.*;
import com.version10.service.UserProfileServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.*;

@ExtendWith(MockitoExtension.class)
public class UserProfileServiceImplTest {

    @Mock
    private UserProfileDAO userProfileDAO;
    @Mock
    private BookAuthorDAO bookAuthorDAO;
    @Mock
    private BookCategoryDAO bookCategoryDAO;
    @Mock
    private BookDAO bookDAO;
    @Mock
    private SearchFactory searchFactory;

    @Mock
    private RecommendationsFactory recommendationsFactory;

    @Mock
    private TemplateSearchStrategy exactSearchStrategy;

    @Mock
    private TemplateSearchStrategy approximateSearchStrategy;

    @Mock
    private TemplateRecommendStrategy recommendByCategory;

    @Mock
    private TemplateRecommendStrategy recommendByAuthors;

    @Mock
    private TemplateRecommendStrategy recommendMixed;

    @InjectMocks
    private UserProfileServiceImpl userProfileService;


    private UserProfile userProfile;
    private BookAuthor bookAuthor;
    private BookCategory bookCategory;
    private Book book;
    private SearchFormData searchFormData;
    private RecommendationsFormData recommendationsFormData;

    private BookFormData bookFormData;

    @BeforeEach
    public void setUp() {
        userProfile = new UserProfile();
        userProfile.setUsername("john");
        userProfile.setFullName("John Tester");
        userProfile.setAge(30);
        userProfile.setAddress("Address 12");
        userProfile.setPhoneNumber("123456789");
        userProfile.setNotifications(new ArrayList<>());
        userProfile.setFavouriteBookAuthors(new ArrayList<>());
        userProfile.setFavouriteBookCategories(new ArrayList<>());
        userProfile.setBookOffers(new ArrayList<>());

        bookAuthor = new BookAuthor();
        bookAuthor.setName("Author One");

        bookCategory = new BookCategory();
        bookCategory.setName("Category One");

        book = new Book();
        book.setBookId(1);
        book.setTitle("Book One");
        book.setSummary("A great book.");
        book.setBookAuthors(Collections.singletonList(bookAuthor));
        book.setBookCategory(bookCategory);
        book.setRequestingUsers(new ArrayList<>());

        searchFormData = new SearchFormData();
        searchFormData.setQueryTitle("Book One");
        searchFormData.setQueryAuthor("Author One");

        recommendationsFormData = new RecommendationsFormData();
        recommendationsFormData.setAuthors(Collections.singletonList("Author One"));
        recommendationsFormData.setCategories(Collections.singletonList("Category One"));

        bookFormData = new BookFormData();
        bookFormData.setTitle("Book One");
        bookFormData.setBookAuthors(Collections.singletonList("Author One"));

    }

    @Test
    public void testRetrieveProfile() {
        when(userProfileDAO.findByUsername("john")).thenReturn(Optional.of(userProfile));

        UserProfileFormData result = userProfileService.retrieveProfile("john");

        assertNotNull(result);
        assertEquals("john", result.getUsername());
        verify(userProfileDAO, times(1)).findByUsername("john");
    }

    @Test
    public void testRetrieveProfileNull() {
        when(userProfileDAO.findByUsername("wrong")).thenReturn(Optional.empty());
        UserProfileFormData result = userProfileService.retrieveProfile("wrong");
        assertNull(result);
    }

    @Test
    public void testSaveUserProfile() {
        UserProfileFormData userProfileFormData = new UserProfileFormData();
        userProfileFormData.setUsername("john");
        userProfileFormData.setFullName("John Tester");
        userProfileFormData.setAge(30);
        userProfileFormData.setAddress("Something 12");
        userProfileFormData.setPhoneNumber("123456789");
        userProfileFormData.setFavouriteBookAuthors(Collections.singletonList("Author One"));
        userProfileFormData.setFavouriteBookCategories(Collections.singletonList("Category One"));

        when(bookAuthorDAO.findByName("Author One")).thenReturn(Optional.of(Collections.singletonList(bookAuthor)));
        when(bookCategoryDAO.findByName("Category One")).thenReturn(Optional.of(Collections.singletonList(bookCategory)));

        userProfileService.save(userProfileFormData);

        verify(userProfileDAO, times(1)).save(any(UserProfile.class));
        verify(bookAuthorDAO, times(1)).findByName("Author One");
        verify(bookCategoryDAO, times(1)).findByName("Category One");
    }

    @Test
    public void testRetrieveBookOffers() {
        userProfile.setBookOffers(Collections.singletonList(book));
        when(userProfileDAO.findByUsername("john")).thenReturn(Optional.of(userProfile));
        List<BookFormData> result = userProfileService.retrieveBookOffers("john");
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("Book One", result.get(0).getTitle());
        verify(userProfileDAO, times(1)).findByUsername("john");
    }

    @Test
    public void testAddBookOffer() {
        when(userProfileDAO.findByUsername("john")).thenReturn(Optional.of(userProfile));
        when(bookDAO.save(any(Book.class))).thenReturn(book);

        BookFormData bookFormData = new BookFormData();
        bookFormData.setBookId(1);
        bookFormData.setTitle("Book One");
        bookFormData.setSummary("A great book.");
        bookFormData.setBookAuthors(Collections.singletonList("Author One"));
        bookFormData.setBookCategory("Category One");

        userProfileService.addBookOffer("john", bookFormData);

        verify(bookDAO, times(1)).save(any(Book.class));
        verify(userProfileDAO, times(1)).save(userProfile);
    }

    @Test
    public void testRequestBook() {
        userProfile.setBookOffers(new ArrayList<>());
        when(userProfileDAO.findByUsername("john")).thenReturn(Optional.of(userProfile));
        when(bookDAO.findById(1)).thenReturn(Optional.of(book));

        userProfileService.requestBook(1, "john");

        verify(bookDAO, times(1)).save(book);
        assertTrue(book.getRequestingUsers().contains(userProfile));
    }

    @Test
    public void testRequestOwnBookThrowsException() {
        userProfile.setBookOffers(Collections.singletonList(book));
        when(userProfileDAO.findByUsername("john")).thenReturn(Optional.of(userProfile));
        when(bookDAO.findById(1)).thenReturn(Optional.of(book));

        assertThrows(SelfBookRequestException.class, () -> userProfileService.requestBook(1, "john"));
    }

    @Test
    public void testRetrieveBookRequests() {
        userProfile.setBookOffers(new ArrayList<>());
        book.setRequestingUsers(Collections.singletonList(userProfile));
        when(userProfileDAO.findByUsername("john")).thenReturn(Optional.of(userProfile));
        when(bookDAO.findAll()).thenReturn(Collections.singletonList(book));

        List<BookFormData> result = userProfileService.retrieveBookRequests("john");

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("Book One", result.get(0).getTitle());
    }

    @Test
    public void testRetrieveRequestingUsers() {
        book.setRequestingUsers(Collections.singletonList(userProfile));
        when(bookDAO.findById(1)).thenReturn(Optional.of(book));

        List<UserProfileFormData> result = userProfileService.retrieveRequestingUsers(1);

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("john", result.get(0).getUsername());
    }

    @Test
    public void testDeleteBookOffer() {
        userProfile.setBookOffers(Collections.singletonList(book));
        when(userProfileDAO.findByUsername("john")).thenReturn(Optional.of(userProfile));
        when(bookDAO.findByBookId(1)).thenReturn(Optional.of(book));

        userProfileService.deleteBookOffer("john", 1);

        verify(bookDAO, times(1)).delete(book);
        verify(userProfileDAO, times(1)).save(userProfile);
    }

    @Test
    public void testDeleteBookRequest() {
        List<UserProfile> requestingUsers = new ArrayList<>();
        requestingUsers.add(userProfile);
        book.setRequestingUsers(requestingUsers);
        when(userProfileDAO.findByUsername("john")).thenReturn(Optional.of(userProfile));
        when(bookDAO.findById(1)).thenReturn(Optional.of(book));

        userProfileService.deleteBookRequest("john", 1);

        verify(bookDAO, times(1)).save(book);
        assertFalse(book.getRequestingUsers().contains(userProfile));
    }

    @Test
    public void testSearchBooksExact() {
        when(exactSearchStrategy.search(any(SearchFormData.class), any(BookDAO.class)))
                .thenReturn(Collections.singletonList(bookFormData));
        when(searchFactory.getStrategy(any(SearchFormData.class)))
                .thenAnswer(invocation -> {
                    SearchFormData formData = invocation.getArgument(0);
                    return formData.isExactSearch() ? exactSearchStrategy : approximateSearchStrategy;
                });
        searchFormData.setExactSearch(true);


        List<BookFormData> results = userProfileService.searchBooks(searchFormData);

        assertNotNull(results);
        assertEquals(1, results.size());
        assertEquals("Book One", results.get(0).getTitle());

        verify(exactSearchStrategy, times(1)).search(searchFormData, bookDAO);
        verify(approximateSearchStrategy, times(0)).search(searchFormData, bookDAO);
    }

    @Test
    public void testSearchBooksApproximate() {
        when(approximateSearchStrategy.search(any(SearchFormData.class), any(BookDAO.class)))
                .thenReturn(Collections.singletonList(bookFormData));
        when(searchFactory.getStrategy(any(SearchFormData.class)))
                .thenAnswer(invocation -> {
                    SearchFormData formData = invocation.getArgument(0);
                    return formData.isExactSearch() ? exactSearchStrategy : approximateSearchStrategy;
                });
        searchFormData.setExactSearch(false);

        List<BookFormData> results = userProfileService.searchBooks(searchFormData);

        assertNotNull(results);
        assertEquals(1, results.size());
        assertEquals("Book One", results.get(0).getTitle());

        verify(approximateSearchStrategy, times(1)).search(searchFormData, bookDAO);
        verify(exactSearchStrategy, times(0)).search(searchFormData, bookDAO);
    }
    @Test
    public void testRecommendBooksByCategory() {
        when(recommendByCategory.recommend(any(RecommendationsFormData.class), any(BookDAO.class)))
                .thenReturn(Collections.singletonList(book));
        when(recommendationsFactory.getRecommendationStrategy(any(RecommendationsFormData.class)))
                .thenAnswer(invocation -> {
                    RecommendationsFormData formData = invocation.getArgument(0);
                    switch (formData.getRecommendationType()) {
                        case CATEGORY:
                            return recommendByCategory;
                        case AUTHOR:
                            return recommendByAuthors;
                        case BOTH:
                        default:
                            return recommendMixed;
                    }
                });
        recommendationsFormData.setRecommendationType(RecommendationsFormData.RecommendationType.CATEGORY);

        List<BookFormData> results = userProfileService.recommendBooks("john",recommendationsFormData);

        assertNotNull(results);
        assertEquals(1, results.size());
        assertEquals("Book One", results.get(0).getTitle());

        verify(recommendByCategory, times(1)).recommend(recommendationsFormData, bookDAO);
        verify(recommendByAuthors, times(0)).recommend(recommendationsFormData, bookDAO);
        verify(recommendMixed, times(0)).recommend(recommendationsFormData, bookDAO);
    }

    @Test
    public void testRecommendBooksByAuthors() {
        when(recommendByAuthors.recommend(any(RecommendationsFormData.class), any(BookDAO.class)))
                .thenReturn(Collections.singletonList(book));
        when(recommendationsFactory.getRecommendationStrategy(any(RecommendationsFormData.class)))
                .thenAnswer(invocation -> {
                    RecommendationsFormData formData = invocation.getArgument(0);
                    switch (formData.getRecommendationType()) {
                        case CATEGORY:
                            return recommendByCategory;
                        case AUTHOR:
                            return recommendByAuthors;
                        case BOTH:
                        default:
                            return recommendMixed;
                    }
                });
        recommendationsFormData.setRecommendationType(RecommendationsFormData.RecommendationType.AUTHOR);

        List<BookFormData> results = userProfileService.recommendBooks("john",recommendationsFormData);

        assertNotNull(results);
        assertEquals(1, results.size());
        assertEquals("Book One", results.get(0).getTitle());

        verify(recommendByAuthors, times(1)).recommend(recommendationsFormData, bookDAO);
        verify(recommendByCategory, times(0)).recommend(recommendationsFormData, bookDAO);
        verify(recommendMixed, times(0)).recommend(recommendationsFormData, bookDAO);
    }

    @Test
    public void testRecommendBooksMixed() {
        when(recommendMixed.recommend(any(RecommendationsFormData.class), any(BookDAO.class)))
                .thenReturn(Collections.singletonList(book));
        when(recommendationsFactory.getRecommendationStrategy(any(RecommendationsFormData.class)))
                .thenAnswer(invocation -> {
                    RecommendationsFormData formData = invocation.getArgument(0);
                    switch (formData.getRecommendationType()) {
                        case CATEGORY:
                            return recommendByCategory;
                        case AUTHOR:
                            return recommendByAuthors;
                        case BOTH:
                        default:
                            return recommendMixed;
                    }
                });
        recommendationsFormData.setRecommendationType(RecommendationsFormData.RecommendationType.BOTH);

        List<BookFormData> results = userProfileService.recommendBooks("john",recommendationsFormData);

        assertNotNull(results);
        assertEquals(1, results.size());
        assertEquals("Book One", results.get(0).getTitle());

        verify(recommendMixed, times(1)).recommend(recommendationsFormData, bookDAO);
        verify(recommendByCategory, times(0)).recommend(recommendationsFormData, bookDAO);
        verify(recommendByAuthors, times(0)).recommend(recommendationsFormData, bookDAO);
    }

    @Test
    public void testAcceptBookRequest() {
        List<String> notifications1 = new ArrayList<>();
        List<String> notifications2 = new ArrayList<>();

        userProfile.setBookOffers(Collections.singletonList(book));

        UserProfile selectedUserProfile = new UserProfile();
        selectedUserProfile.setUsername("selected_user");
        selectedUserProfile.setNotifications(notifications1);

        UserProfile requestingUserProfile = new UserProfile();
        requestingUserProfile.setUsername("requesting_user");
        requestingUserProfile.setNotifications(notifications2);

        // Set up book with requesting users
        book.setRequestingUsers(Arrays.asList(requestingUserProfile, selectedUserProfile));

        // Mock DAO responses
        when(bookDAO.findById(1)).thenReturn(Optional.of(book));
        when(bookDAO.findByBookId(1)).thenReturn(Optional.of(book));
        when(userProfileDAO.findByUsername("john")).thenReturn(Optional.of(userProfile));
        when(userProfileDAO.findByUsername("selected_user")).thenReturn(Optional.of(selectedUserProfile));

        // Call the service method
        userProfileService.acceptBookRequest("john", "selected_user", 1);

        // Verify that the notifications were added
        assertEquals("You have been selected to receive the book: " + book.getTitle(), selectedUserProfile.getNotifications().get(0));
        assertEquals("Book " + book.getTitle() + " has been taken by another user.", requestingUserProfile.getNotifications().get(0));

        // Verify the interactions with DAOs
        verify(userProfileDAO, times(1)).save(selectedUserProfile);
        verify(userProfileDAO, times(1)).save(requestingUserProfile);
        verify(bookDAO, times(1)).delete(book);
    }
}
