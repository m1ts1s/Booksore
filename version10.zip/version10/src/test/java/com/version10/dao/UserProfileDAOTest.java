package com.version10.dao;

import com.version10.domain.UserProfile;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class UserProfileDAOTest {

    @Mock
    private UserProfileDAO userProfileDAO;

    private UserProfile userProfile;

    @BeforeEach
    public void setUp() {
        // Initialize a UserProfile object
        userProfile = new UserProfile();
        userProfile.setProfileId(1);
        userProfile.setUsername("testuser");
        userProfile.setFullName("Test User");
        userProfile.setAge(30);
        userProfile.setAddress("123 Test St");
        userProfile.setPhoneNumber("123-456-7890");
    }

    @Test
    public void testFindByUsername() {
        // Mocking behavior
        when(userProfileDAO.findByUsername("testuser")).thenReturn(Optional.of(userProfile));

        // Test the DAO method
        Optional<UserProfile> result = userProfileDAO.findByUsername("testuser");

        // Verify the result
        assertTrue(result.isPresent());
        assertEquals("testuser", result.get().getUsername());
        assertEquals("Test User", result.get().getFullName());
    }

    @Test
    public void testFindByUsernameNotFound() {
        // Mocking behavior for a non-existing user
        when(userProfileDAO.findByUsername("nonexistinguser")).thenReturn(Optional.empty());

        // Test the DAO method
        Optional<UserProfile> result = userProfileDAO.findByUsername("nonexistinguser");

        // Verify the result
        assertTrue(result.isEmpty());
    }
}
