package com.version10.dao;

import com.version10.domain.User;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class UserDAOTest {

    @Mock
    private UserDAO userDAO;

    private User user;

    @BeforeEach
    public void setUp() {
        // Initialize a User object
        user = new User();
        user.setId(1);
        user.setUsername("testuser");
        user.setPassword("password");
    }

    @Test
    public void testFindByUsername() {
        // Mocking behavior
        when(userDAO.findByUsername("testuser")).thenReturn(Optional.of(user));

        // Test the DAO method
        Optional<User> result = userDAO.findByUsername("testuser");

        // Verify the result
        assertTrue(result.isPresent());
        assertEquals("testuser", result.get().getUsername());
    }

    @Test
    public void testFindByUsernameNotFound() {
        // Mocking behavior for a non-existing user
        when(userDAO.findByUsername("nonexistinguser")).thenReturn(Optional.empty());

        // Test the DAO method
        Optional<User> result = userDAO.findByUsername("nonexistinguser");

        // Verify the result
        assertTrue(result.isEmpty());
    }
}
