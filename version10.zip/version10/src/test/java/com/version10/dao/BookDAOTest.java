package com.version10.dao;

import com.version10.domain.Book;
import com.version10.domain.BookAuthor;
import com.version10.domain.BookCategory;
import com.version10.domain.UserProfile;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class BookDAOTest {

    @Mock
    private BookDAO bookDAO;

    private Book book;
    private List<Book> books;

    @BeforeEach
    public void setUp() {
        // Initialize Book objects
        book = new Book();
        book.setBookId(1);
        book.setTitle("Test Book");

        BookAuthor author = new BookAuthor();
        author.setAuthorId(1);
        author.setName("Author Name");
        List<BookAuthor> authors = new ArrayList<>();
        authors.add(author);
        book.setBookAuthors(authors);

        BookCategory category = new BookCategory();
        category.setCategoryId(1);
        category.setName("Fiction");
        book.setBookCategory(category);

        UserProfile userProfile = new UserProfile();
        userProfile.setProfileId(1);
        userProfile.setUsername("testuser");
        //book.setUserProfile(userProfile);

        books = new ArrayList<>();
        books.add(book);
    }

    @Test
    public void testFindByTitle() {
        // Mocking behavior
        when(bookDAO.findByTitle("Test Book")).thenReturn(Optional.of(books));

        // Test the DAO method
        Optional<List<Book>> result = bookDAO.findByTitle("Test Book");

        // Verify the result
        assertTrue(result.isPresent());
        assertEquals(1, result.get().size());
        assertEquals("Test Book", result.get().get(0).getTitle());
    }

    @Test
    public void testFindByTitleContaining() {
        // Mocking behavior
        when(bookDAO.findByTitleContaining("Test")).thenReturn(Optional.of(books));

        // Test the DAO method
        Optional<List<Book>> result = bookDAO.findByTitleContaining("Test");

        // Verify the result
        assertTrue(result.isPresent());
        assertEquals(1, result.get().size());
        assertEquals("Test Book", result.get().get(0).getTitle());
    }

    @Test
    public void testFindByBookId() {
        // Mocking behavior
        when(bookDAO.findByBookId(1)).thenReturn(Optional.of(book));

        // Test the DAO method
        Optional<Book> result = bookDAO.findByBookId(1);

        // Verify the result
        assertTrue(result.isPresent());
        assertEquals(1, result.get().getBookId());
    }

    @Test
    public void testFindByTitleNotFound() {
        // Mocking behavior for a non-existing book
        when(bookDAO.findByTitle("Non-Existing Book")).thenReturn(Optional.empty());

        // Test the DAO method
        Optional<List<Book>> result = bookDAO.findByTitle("Non-Existing Book");

        // Verify the result
        assertTrue(result.isEmpty());
    }

    @Test
    public void testFindByTitleContainingNotFound() {
        // Mocking behavior for a non-existing book
        when(bookDAO.findByTitleContaining("Non-Existing")).thenReturn(Optional.empty());

        // Test the DAO method
        Optional<List<Book>> result = bookDAO.findByTitleContaining("Non-Existing");

        // Verify the result
        assertTrue(result.isEmpty());
    }

    @Test
    public void testFindByBookIdNotFound() {
        // Mocking behavior for a non-existing book
        when(bookDAO.findByBookId(999)).thenReturn(Optional.empty());

        // Test the DAO method
        Optional<Book> result = bookDAO.findByBookId(999);

        // Verify the result
        assertTrue(result.isEmpty());
    }
}
