//package com.version10.dao;
//
//import com.version10.domain.BookAuthor;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.Mock;
//import org.mockito.junit.jupiter.MockitoExtension;
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Optional;
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.mockito.Mockito.when;
//
//@ExtendWith(MockitoExtension.class)
//public class BookAuthorDAOTest {
//
//    @Mock
//    private BookAuthorDAO bookAuthorDAO;
//
//
//    @Test
//    public void testFindByName() {
//        List<BookAuthor> authors = new ArrayList<>();
//        BookAuthor author = new BookAuthor();
//        author.setAuthorId(1);
//        author.setName("Author Name");
//        authors.add(author);
//
//        when(bookAuthorDAO.findByName("Author Name")).thenReturn(Optional.of(authors));
//
//        List<BookAuthor> result = bookAuthorDAO.findByName("Author Name").get();
//        // Verify the result
//        assertEquals(1, result.size());
//        assertEquals("Author Name", result.get(0).getName());
//    }
//}
package com.version10.dao;

import com.version10.domain.BookAuthor;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class BookAuthorDAOTest {

    @Mock
    private BookAuthorDAO bookAuthorDAO;

    private List<BookAuthor> authors;

    @BeforeEach
    public void setUp() {
        // Initialize a list of BookAuthors
        authors = new ArrayList<>();
        BookAuthor author1 = new BookAuthor();
        author1.setAuthorId(1);
        author1.setName("Author Name");

        BookAuthor author2 = new BookAuthor();
        author2.setAuthorId(2);
        author2.setName("Another Author");

        authors.add(author1);
        authors.add(author2);
    }

    @Test
    public void testFindByName() {
        // Mocking behavior
        when(bookAuthorDAO.findByName("Author Name")).thenReturn(Optional.of(authors));

        // Test the DAO method
        Optional<List<BookAuthor>> result = bookAuthorDAO.findByName("Author Name");

        // Verify the result
        assertTrue(result.isPresent());
        assertEquals(2, result.get().size());
        assertEquals("Author Name", result.get().get(0).getName());
    }

}

