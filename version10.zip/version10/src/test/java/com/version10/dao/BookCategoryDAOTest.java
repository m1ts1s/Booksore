package com.version10.dao;

import com.version10.domain.BookCategory;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class BookCategoryDAOTest {

    @Mock
    private BookCategoryDAO bookCategoryDAO;


    @Test
    public void testFindByName() {
        // Mocking data
        List<BookCategory> categories = new ArrayList<>();
        BookCategory category = new BookCategory();
        category.setCategoryId(1);
        category.setName("Fiction");
        categories.add(category);

        // Mocking behavior
        when(bookCategoryDAO.findByName("Fiction")).thenReturn(Optional.of(categories));

        // Test the service method
        List<BookCategory> result = bookCategoryDAO.findByName("Fiction").orElse(new ArrayList<>());

        // Verify the result
        assertEquals(1, result.size());
        assertEquals("Fiction", result.get(0).getName());
    }
}
