package com.version10.controller;
import com.version10.controller.UserController;
import com.version10.domain.Book;
import com.version10.domain.UserProfile;
import com.version10.exception.SelfBookRequestException;
import com.version10.formsdata.BookFormData;
import com.version10.formsdata.RecommendationsFormData;
import com.version10.formsdata.SearchFormData;
import com.version10.formsdata.UserProfileFormData;
import com.version10.service.UserProfileService;
import com.version10.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.ui.Model;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;


@AutoConfigureMockMvc
@SpringBootTest
public class UserControllerTest {

    @Mock
    private UserService userService;

    @Mock
    private UserProfileService userProfileService;

    @Autowired
    private WebApplicationContext webApplicationContext;

    @InjectMocks
    private UserController userController;

    @Mock
    private Model model;
    private MockMvc mockMvc;

    @Mock
    private RedirectAttributes redirectAttributes;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
        mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();

    }

    @Test
    void testGetUserMainMenu() {
        String viewName = userController.getUserMainMenu();
        assertEquals("mainMenu", viewName);
    }

    @Test
    void testRetrieveProfile() {
        Authentication authentication = mock(Authentication.class);
        Model model = mock(Model.class);
        SecurityContextHolder.getContext().setAuthentication(authentication);
        String viewName = userController.retrieveProfile(model);
        assertEquals("viewProfile", viewName);
    }

    @Test
    void testGetProfileMenu() throws Exception{
        mockMvc.perform(MockMvcRequestBuilders.get("/profile"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.view().name("profileMenu"));
    }
    @Test
    public void testCreateProfile() throws Exception {
        Authentication authentication = mock(Authentication.class);
        SecurityContextHolder.getContext().setAuthentication(authentication);
        mockMvc.perform(MockMvcRequestBuilders.get("/createProfile"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.view().name("createProfile"));
    }

    @Test
    @WithMockUser(username = "testUser", roles = {"USER"})
    public void testShowRequesters() throws Exception {
        // Perform GET request to /showRequesters
        mockMvc.perform(MockMvcRequestBuilders.get("/showRequesters"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.view().name("viewRequestedBookOffers"))
                .andExpect(MockMvcResultMatchers.model().attributeExists("bookOffers"))
                .andExpect(MockMvcResultMatchers.model().attributeExists("username"));
    }

    @Test
    @WithMockUser(username = "testUser", roles = {"USER"})
    public void testShowOfferForm() throws Exception {
        // Perform GET request to /offerForm
        mockMvc.perform(MockMvcRequestBuilders.get("/offerForm"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.view().name("offerForm"))
                .andExpect(MockMvcResultMatchers.model().attributeExists("bookForm"));
    }

    @Test
    @WithMockUser(username = "testUser", roles = {"USER"})
    public void testListBookOffers() throws Exception {
        // Perform GET request to /listBookOffers
        mockMvc.perform(MockMvcRequestBuilders.get("/listBookOffers"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.view().name("offerList"))
                .andExpect(MockMvcResultMatchers.model().attributeExists("bookOffers"))
                .andExpect(MockMvcResultMatchers.model().attributeExists("username"));
    }

    @Test
    @WithMockUser(username = "testUser", roles = {"USER"})
    public void testShowSearchForm() throws Exception {
        // Perform GET request to /searchForm
        mockMvc.perform(MockMvcRequestBuilders.get("/searchForm"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.view().name("searchForm"))
                .andExpect(MockMvcResultMatchers.model().attributeExists("searchForm"));
    }

    @Test
    @WithMockUser(username = "testUser", roles = {"USER"})
    public void testShowRecommendationsForm() throws Exception {
        // Perform GET request to /showRecommendationsForm
        mockMvc.perform(MockMvcRequestBuilders.get("/showRecommendationsForm"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.view().name("recommendationForm"));
    }

    @Test
    void testShowUserBookRequests() {
        Authentication authentication = mock(Authentication.class);
        Model model = mock(Model.class);
        SecurityContextHolder.getContext().setAuthentication(authentication);
        String viewName = userController.showUserBookRequests(model);
        assertEquals("viewUserBookRequests", viewName);
    }

    @Test
    @WithMockUser(username = "testUser", roles = {"USER"}) // Mock authenticated user
    public void testShowUserNotifications() throws Exception {
        // Mock the UserProfileService behavior for retrieveProfile method
        UserProfileFormData userProfileFormData = new UserProfileFormData();
        userProfileFormData.setUsername("testUser");
        Mockito.when(userProfileService.retrieveProfile(anyString())).thenReturn(userProfileFormData);

        // Perform GET request to /viewUserNotifications
        mockMvc.perform(MockMvcRequestBuilders.get("/viewUserNotifications"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.view().name("viewUserNotifications"))
                .andExpect(MockMvcResultMatchers.model().attributeExists("userProfile"));
    }

    @Test
    @WithMockUser(username = "testOwner", roles = {"USER"}) // Mock authenticated user
    public void testAcceptRequest() throws Exception {
        // Mock the UserProfileService behavior for acceptBookRequest method
        Mockito.doNothing().when(userProfileService).acceptBookRequest(anyString(), anyString(), anyInt());

        // Perform GET request to /acceptRequest/{username}/{bookId}
        mockMvc.perform(MockMvcRequestBuilders.get("/acceptRequest/testUser/1"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.view().name("viewRequestingUsers"));
    }

    @Test
    void testDeleteBookRequest() {
        String username = "testUser";
        int bookId = 1;

        doNothing().when(userProfileService).deleteBookRequest(username, bookId);

        String viewName = userController.deleteBookRequest(username, bookId, model);

        assertEquals("viewUserBookRequests", viewName);
        verify(userProfileService, times(1)).deleteBookRequest(username, bookId);
        verify(model, times(1)).addAttribute("success", "Book deletion successful");
    }

}

