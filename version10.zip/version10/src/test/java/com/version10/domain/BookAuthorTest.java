package com.version10.domain;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class BookAuthorTest {

    private BookAuthor bookAuthor;
    private List<Book> books;

    @BeforeEach
    public void setUp() {
        books = new ArrayList<>();
        Book book = new Book();
        book.setBookId(1);
        book.setTitle("Test Book");
        books.add(book);

        bookAuthor = new BookAuthor();
        bookAuthor.setAuthorId(1);
        bookAuthor.setName("Author Name");
        bookAuthor.setBooks(books);
    }

    @Test
    public void testGetAuthorId() {
        assertEquals(1, bookAuthor.getAuthorId());
    }

    @Test
    public void testGetName() {
        assertEquals("Author Name", bookAuthor.getName());
    }

    @Test
    public void testGetBooks() {
        assertNotNull(bookAuthor.getBooks());
        assertEquals(1, bookAuthor.getBooks().size());
        assertEquals("Test Book", bookAuthor.getBooks().get(0).getTitle());
    }

    @Test
    public void testSetAuthorId() {
        bookAuthor.setAuthorId(2);
        assertEquals(2, bookAuthor.getAuthorId());
    }

    @Test
    public void testSetName() {
        bookAuthor.setName("New Author Name");
        assertEquals("New Author Name", bookAuthor.getName());
    }

    @Test
    public void testSetBooks() {
        List<Book> newBooks = new ArrayList<>();
        Book newBook = new Book();
        newBook.setBookId(2);
        newBook.setTitle("New Test Book");
        newBooks.add(newBook);
        bookAuthor.setBooks(newBooks);
        assertEquals(1, bookAuthor.getBooks().size());
        assertEquals("New Test Book", bookAuthor.getBooks().get(0).getTitle());
    }
}
