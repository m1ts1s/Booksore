package com.version10.domain;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class UserProfileTest {

    private UserProfile userProfile;
    private List<BookAuthor> favouriteBookAuthors;
    private List<BookCategory> favouriteBookCategories;
    private List<Book> bookOffers;
    private List<String> notifications;

    @BeforeEach
    public void setUp() {
        favouriteBookAuthors = new ArrayList<>();
        BookAuthor author = new BookAuthor();
        author.setAuthorId(1);
        author.setName("Author Name");
        favouriteBookAuthors.add(author);

        favouriteBookCategories = new ArrayList<>();
        BookCategory category = new BookCategory();
        category.setCategoryId(1);
        category.setName("Fiction");
        favouriteBookCategories.add(category);

        bookOffers = new ArrayList<>();
        Book book = new Book();
        book.setBookId(1);
        book.setTitle("Test Book");
        bookOffers.add(book);

        notifications = new ArrayList<>();
        notifications.add("New book available");

        userProfile = new UserProfile();
        userProfile.setProfileId(1);
        userProfile.setUsername("testuser");
        userProfile.setFullName("Test User");
        userProfile.setAge(30);
        userProfile.setAddress("123 Test St");
        userProfile.setPhoneNumber("123-456-7890");
        userProfile.setFavouriteBookAuthors(favouriteBookAuthors);
        userProfile.setFavouriteBookCategories(favouriteBookCategories);
        userProfile.setBookOffers(bookOffers);
        userProfile.setNotifications(notifications);
    }

    @Test
    public void testGetProfileId() {
        assertEquals(1, userProfile.getProfileId());
    }

    @Test
    public void testGetUsername() {
        assertEquals("testuser", userProfile.getUsername());
    }

    @Test
    public void testGetFullName() {
        assertEquals("Test User", userProfile.getFullName());
    }

    @Test
    public void testGetAge() {
        assertEquals(30, userProfile.getAge());
    }

    @Test
    public void testGetAddress() {
        assertEquals("123 Test St", userProfile.getAddress());
    }

    @Test
    public void testGetPhoneNumber() {
        assertEquals("123-456-7890", userProfile.getPhoneNumber());
    }

    @Test
    public void testGetFavouriteBookAuthors() {
        assertNotNull(userProfile.getFavouriteBookAuthors());
        assertEquals(1, userProfile.getFavouriteBookAuthors().size());
        assertEquals("Author Name", userProfile.getFavouriteBookAuthors().get(0).getName());
    }

    @Test
    public void testGetFavouriteBookCategories() {
        assertNotNull(userProfile.getFavouriteBookCategories());
        assertEquals(1, userProfile.getFavouriteBookCategories().size());
        assertEquals("Fiction", userProfile.getFavouriteBookCategories().get(0).getName());
    }

    @Test
    public void testGetBookOffers() {
        assertNotNull(userProfile.getBookOffers());
        assertEquals(1, userProfile.getBookOffers().size());
        assertEquals("Test Book", userProfile.getBookOffers().get(0).getTitle());
    }

    @Test
    public void testGetNotifications() {
        assertNotNull(userProfile.getNotifications());
        assertEquals(1, userProfile.getNotifications().size());
        assertEquals("New book available", userProfile.getNotifications().get(0));
    }

    @Test
    public void testSetProfileId() {
        userProfile.setProfileId(2);
        assertEquals(2, userProfile.getProfileId());
    }

    @Test
    public void testSetUsername() {
        userProfile.setUsername("newuser");
        assertEquals("newuser", userProfile.getUsername());
    }

    @Test
    public void testSetFullName() {
        userProfile.setFullName("New User");
        assertEquals("New User", userProfile.getFullName());
    }

    @Test
    public void testSetAge() {
        userProfile.setAge(25);
        assertEquals(25, userProfile.getAge());
    }

    @Test
    public void testSetAddress() {
        userProfile.setAddress("456 New St");
        assertEquals("456 New St", userProfile.getAddress());
    }

    @Test
    public void testSetPhoneNumber() {
        userProfile.setPhoneNumber("987-654-3210");
        assertEquals("987-654-3210", userProfile.getPhoneNumber());
    }

    @Test
    public void testSetFavouriteBookAuthors() {
        List<BookAuthor> newAuthors = new ArrayList<>();
        BookAuthor newAuthor = new BookAuthor();
        newAuthor.setAuthorId(2);
        newAuthor.setName("New Author");
        newAuthors.add(newAuthor);
        userProfile.setFavouriteBookAuthors(newAuthors);
        assertEquals(1, userProfile.getFavouriteBookAuthors().size());
        assertEquals("New Author", userProfile.getFavouriteBookAuthors().get(0).getName());
    }

    @Test
    public void testSetFavouriteBookCategories() {
        List<BookCategory> newCategories = new ArrayList<>();
        BookCategory newCategory = new BookCategory();
        newCategory.setCategoryId(2);
        newCategory.setName("Non-Fiction");
        newCategories.add(newCategory);
        userProfile.setFavouriteBookCategories(newCategories);
        assertEquals(1, userProfile.getFavouriteBookCategories().size());
        assertEquals("Non-Fiction", userProfile.getFavouriteBookCategories().get(0).getName());
    }

    @Test
    public void testSetBookOffers() {
        List<Book> newBooks = new ArrayList<>();
        Book newBook = new Book();
        newBook.setBookId(2);
        newBook.setTitle("New Test Book");
        newBooks.add(newBook);
        userProfile.setBookOffers(newBooks);
        assertEquals(1, userProfile.getBookOffers().size());
        assertEquals("New Test Book", userProfile.getBookOffers().get(0).getTitle());
    }

    @Test
    public void testSetNotifications() {
        List<String> newNotifications = new ArrayList<>();
        newNotifications.add("Another notification");
        userProfile.setNotifications(newNotifications);
        assertEquals(1, userProfile.getNotifications().size());
        assertEquals("Another notification", userProfile.getNotifications().get(0));
    }
}
