package com.version10.domain;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class BookTest {

    private Book book;
    private UserProfile userProfile;
    private List<BookAuthor> bookAuthors;
    private BookCategory bookCategory;
    private List<UserProfile> requestingUsers;

    @BeforeEach
    public void setUp() {
        // Setting up UserProfile
        userProfile = new UserProfile();
        userProfile.setProfileId(1);
        userProfile.setUsername("testuser");
        userProfile.setFullName("Test User");
        userProfile.setAge(30);
        userProfile.setAddress("123 Test St");
        userProfile.setPhoneNumber("123-456-7890");

        // Setting up BookAuthors
        bookAuthors = new ArrayList<>();
        BookAuthor author = new BookAuthor();
        author.setAuthorId(1);
        author.setName("Author Name");
        bookAuthors.add(author);

        // Setting up BookCategory
        bookCategory = new BookCategory();
        bookCategory.setCategoryId(1);
        bookCategory.setName("Fiction");

        // Setting up RequestingUsers
        requestingUsers = new ArrayList<>();
        UserProfile requestingUser = new UserProfile();
        requestingUser.setProfileId(2);
        requestingUser.setUsername("requestuser");
        requestingUser.setFullName("Request User");
        requestingUsers.add(requestingUser);

        // Setting up Book
        book = new Book();
        book.setBookId(1);
        book.setTitle("Test Book");
        book.setSummary("This is a test book");
        //book.setUserProfile(userProfile);
        book.setBookAuthors(bookAuthors);
        book.setBookCategory(bookCategory);
        book.setRequestingUsers(requestingUsers);
    }

    @Test
    public void testGetBookId() {
        assertEquals(1, book.getBookId());
    }

    @Test
    public void testGetTitle() {
        assertEquals("Test Book", book.getTitle());
    }

    @Test
    public void testGetSummary() {
        assertEquals("This is a test book", book.getSummary());
    }

    @Test
    public void testGetBookAuthors() {
        assertNotNull(book.getBookAuthors());
        assertEquals(1, book.getBookAuthors().size());
        assertEquals("Author Name", book.getBookAuthors().get(0).getName());
    }

    @Test
    public void testGetBookCategory() {
        assertNotNull(book.getBookCategory());
        assertEquals("Fiction", book.getBookCategory().getName());
    }

    @Test
    public void testGetRequestingUsers() {
        assertNotNull(book.getRequestingUsers());
        assertEquals(1, book.getRequestingUsers().size());
        assertEquals("requestuser", book.getRequestingUsers().get(0).getUsername());
    }

    @Test
    public void testSetBookId() {
        book.setBookId(2);
        assertEquals(2, book.getBookId());
    }

    @Test
    public void testSetTitle() {
        book.setTitle("New Test Book");
        assertEquals("New Test Book", book.getTitle());
    }

    @Test
    public void testSetSummary() {
        book.setSummary("This is a new test book");
        assertEquals("This is a new test book", book.getSummary());
    }

    @Test
    public void testSetBookAuthors() {
        List<BookAuthor> newAuthors = new ArrayList<>();
        BookAuthor newAuthor = new BookAuthor();
        newAuthor.setAuthorId(2);
        newAuthor.setName("New Author");
        newAuthors.add(newAuthor);
        book.setBookAuthors(newAuthors);
        assertEquals(1, book.getBookAuthors().size());
        assertEquals("New Author", book.getBookAuthors().get(0).getName());
    }

    @Test
    public void testSetBookCategory() {
        BookCategory newCategory = new BookCategory();
        newCategory.setCategoryId(2);
        newCategory.setName("Non-Fiction");
        book.setBookCategory(newCategory);
        assertEquals("Non-Fiction", book.getBookCategory().getName());
    }

    @Test
    public void testSetRequestingUsers() {
        List<UserProfile> newRequestingUsers = new ArrayList<>();
        UserProfile newRequestingUser = new UserProfile();
        newRequestingUser.setProfileId(3);
        newRequestingUser.setUsername("newrequestuser");
        newRequestingUsers.add(newRequestingUser);
        book.setRequestingUsers(newRequestingUsers);
        assertEquals(1, book.getRequestingUsers().size());
        assertEquals("newrequestuser", book.getRequestingUsers().get(0).getUsername());
    }

    @Test
    public void testToString() {
        String expected = "Book{title='Test Book', bookAuthors=[BookAuthor{name='Author Name', books=null}], bookCategory=BookCategory{name='Fiction', books=null}}";
        assertEquals(expected, book.toString());
    }
}
