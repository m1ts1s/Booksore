package com.version10.domain;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class BookCategoryTest {

    private BookCategory bookCategory;
    private List<Book> books;

    @BeforeEach
    public void setUp() {
        books = new ArrayList<>();
        Book book = new Book();
        book.setBookId(1);
        book.setTitle("Test Book");
        books.add(book);

        bookCategory = new BookCategory();
        bookCategory.setCategoryId(1);
        bookCategory.setName("Fiction");
        bookCategory.setBooks(books);
    }

    @Test
    public void testGetCategoryId() {
        assertEquals(1, bookCategory.getCategoryId());
    }

    @Test
    public void testGetName() {
        assertEquals("Fiction", bookCategory.getName());
    }

    @Test
    public void testGetBooks() {
        assertNotNull(bookCategory.getBooks());
        assertEquals(1, bookCategory.getBooks().size());
        assertEquals("Test Book", bookCategory.getBooks().get(0).getTitle());
    }

    @Test
    public void testSetCategoryId() {
        bookCategory.setCategoryId(2);
        assertEquals(2, bookCategory.getCategoryId());
    }

    @Test
    public void testSetName() {
        bookCategory.setName("Non-Fiction");
        assertEquals("Non-Fiction", bookCategory.getName());
    }

    @Test
    public void testSetBooks() {
        List<Book> newBooks = new ArrayList<>();
        Book newBook = new Book();
        newBook.setBookId(2);
        newBook.setTitle("New Test Book");
        newBooks.add(newBook);
        bookCategory.setBooks(newBooks);
        assertEquals(1, bookCategory.getBooks().size());
        assertEquals("New Test Book", bookCategory.getBooks().get(0).getTitle());
    }
}
