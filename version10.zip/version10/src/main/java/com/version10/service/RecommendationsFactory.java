package com.version10.service;

import com.version10.formsdata.RecommendationsFormData;
import org.springframework.stereotype.Component;

@Component
public class RecommendationsFactory {

    public TemplateRecommendStrategy getRecommendationStrategy(RecommendationsFormData recommendationsFormData){
        if (recommendationsFormData.getRecommendationType() == RecommendationsFormData.RecommendationType.CATEGORY){
            return new RecommendByCategory();
        } else if (recommendationsFormData.getRecommendationType() == RecommendationsFormData.RecommendationType.AUTHOR) {
            return new RecommendByAuthors();
        }else {
            return new RecommendMixed();
        }
    }
}
