package com.version10.service;

import com.version10.dao.BookDAO;
import com.version10.formsdata.BookFormData;
import com.version10.formsdata.RecommendationsFormData;
import com.version10.formsdata.SearchFormData;
import org.springframework.stereotype.Component;
import com.version10.domain.Book;

import java.util.List;

@Component
public interface RecommendStrategy {
    List<Book> recommend(RecommendationsFormData recommendationsFormData, BookDAO bookDAO);
}
