package com.version10.service;

import com.version10.dao.BookDAO;
import com.version10.domain.Book;
import com.version10.domain.BookAuthor;
import com.version10.formsdata.SearchFormData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@Component
public class ApproximateSearchStrategy extends TemplateSearchStrategy{

    @Override
    public List<Book> makeInitialListOfBooks(SearchFormData searchFormData) {
        List<Book> resultBooks = new ArrayList<>(bookDAO.findByTitleContaining(searchFormData.getQueryTitle()).orElse(Collections.emptyList()));
        resultBooks.removeIf(book -> !checkIfAuthorMatch(searchFormData, book));
        return resultBooks;
    }

    @Override
    public boolean checkIfAuthorMatch(SearchFormData searchFormData, Book book) {
        List<String> authors = new ArrayList<>();
        List<String> searchAuthors = Arrays.asList(searchFormData.getQueryAuthor().split(","));
        for (BookAuthor bookAuthor:book.getBookAuthors()){
            authors.add(bookAuthor.getName());
        }
        if (authors.containsAll(searchAuthors)){
            return true;
        }
        return false;
    }

}
