package com.version10.service;

import com.version10.dao.BookAuthorDAO;
import com.version10.dao.BookCategoryDAO;
import com.version10.dao.BookDAO;
import com.version10.dao.UserProfileDAO;
import com.version10.domain.*;
import com.version10.exception.SelfBookRequestException;
import com.version10.formsdata.*;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class UserProfileServiceImpl implements UserProfileService{

    @Autowired
    private UserProfileDAO userProfileDAO;
    @Autowired
    private BookAuthorDAO bookAuthorDAO;
    @Autowired
    private BookCategoryDAO bookCategoryDAO;
    @Autowired
    private BookDAO bookDAO;
    @Autowired
    private SearchFactory searchFactory;
    @Autowired
    private RecommendationsFactory recommendationsFactory;


    @Override
    public UserProfileFormData retrieveProfile(String username) {
        Optional<UserProfile> userProfileOptional = userProfileDAO.findByUsername(username);
        if (!userProfileOptional.isPresent()){
            return null;
        }
        UserProfile userProfile = userProfileOptional.get();
        return convertToUserProfileFormData(userProfile);
    }

    @Override
    public void save(UserProfileFormData userProfileFormData) {
        UserProfile userProfile = new UserProfile();
        userProfile.setUsername(userProfileFormData.getUsername());
        userProfile.setFullName(userProfileFormData.getFullName());
        userProfile.setAge(userProfileFormData.getAge());
        userProfile.setAddress(userProfileFormData.getAddress());
        userProfile.setPhoneNumber(userProfileFormData.getPhoneNumber());

        //Favourite BookAuthors conversion
        List<BookAuthor> authors = new ArrayList<>();
        if (userProfileFormData.getFavouriteBookAuthors() != null) {
            for (String authorName : userProfileFormData.getFavouriteBookAuthors()) {
                List<BookAuthor> foundAuthors = bookAuthorDAO.findByName(authorName)
                        .orElseGet(ArrayList::new); // Get the list if present, or an empty list if not
                if (foundAuthors.isEmpty()) {
                    // If no authors are found, create a new one
                    BookAuthor newAuthor = new BookAuthor();
                    newAuthor.setName(authorName);
                    BookAuthor savedAuthor = bookAuthorDAO.save(newAuthor);
                    authors.add(savedAuthor); // Add the newly saved author
                } else {
                    authors.addAll(foundAuthors); // Add all found authors
                }
            }
        }
        userProfile.setFavouriteBookAuthors(authors);

        //Favourite BookCategories conversion

        List<BookCategory> categories = new ArrayList<>(); // Ensure this is a List<BookCategory>
        if (userProfileFormData.getFavouriteBookCategories() != null) {
            for (String categoryName : userProfileFormData.getFavouriteBookCategories()) {
                List<BookCategory> foundCategories = bookCategoryDAO.findByName(categoryName)
                        .orElseGet(ArrayList::new); // Get the list if present, or an empty list if not
                if (foundCategories.isEmpty()) {
                    BookCategory newCategory = new BookCategory();
                    newCategory.setName(categoryName);
                    BookCategory savedCategory = bookCategoryDAO.save(newCategory);
                    categories.add(savedCategory); // Add the newly saved category
                } else {
                    categories.addAll(foundCategories); // Add all found categories
                }
            }
        }

        userProfile.setFavouriteBookCategories(categories); // Set the list of categories to the userProfile

        userProfileDAO.save(userProfile);
    }

    public List<BookFormData> retrieveBookOffers(String username) {
        UserProfile userProfile = userProfileDAO.findByUsername(username).orElseThrow(() -> new RuntimeException("User not found (retrieveBookOffers)"));
        List<BookFormData> returnList = new ArrayList<>();
        for(Book bookOffer : userProfile.getBookOffers()){
            returnList.add(convertToBookFormData(bookOffer));
        }
        return returnList;
    }

    @Override
    public void addBookOffer(String username, BookFormData bookFormData) {
        UserProfile userProfile = userProfileDAO.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found"));
        Book book = convertToBook(bookFormData);
        bookDAO.save(book);
        List<Book> bookOffers = userProfile.getBookOffers();
        bookOffers.add(book);
        userProfile.setBookOffers(bookOffers);
        userProfileDAO.save(userProfile);
    }

    @Override
    public void requestBook(int bookId, String username) {
        Book bookRequested = bookDAO.findById(bookId).orElseThrow(() -> new RuntimeException("Book not found"));
        UserProfile userProfile = userProfileDAO.findByUsername(username).orElseThrow(() -> new IllegalStateException("UserProfile not found"));
        for(Book book: userProfile.getBookOffers()){
            if (book.equals(bookRequested)) {
                throw new SelfBookRequestException("You cannot request your own book.");
            }
        }
        List<UserProfile> currentRequestingUsers = bookRequested.getRequestingUsers();
        if (!currentRequestingUsers.contains(userProfile)) {
            currentRequestingUsers.add(userProfile);
        }
        // Update the requesting users for the book
        bookRequested.setRequestingUsers(currentRequestingUsers);
        bookDAO.save(bookRequested);
    }


    @Override
    public List<BookFormData> retrieveBookRequests(String username) {
        UserProfile userProfile = userProfileDAO.findByUsername(username).orElseThrow(() -> new IllegalStateException("UserProfile not found"));
        List<BookFormData> returnBooks = new ArrayList<>();
        List<Book> allBooks = bookDAO.findAll();
        for (Book book : allBooks) {
            if (book.getRequestingUsers().contains(userProfile)) {
                returnBooks.add(convertToBookFormData(book));
            }
        }
        return returnBooks;
    }

    @Override
    public List<UserProfileFormData> retrieveRequestingUsers(int bookId) {
        Book book = bookDAO.findById(bookId).orElseThrow(() -> new IllegalStateException("Book not found"));
        List<UserProfile> requestingUsers = book.getRequestingUsers();
        List<UserProfileFormData> returnUsers = new ArrayList<>();
        for (UserProfile userProfile : requestingUsers) {
            returnUsers.add(convertToUserProfileFormData(userProfile));
        }
        return returnUsers;
    }

    @Override
    @Transactional
    public void deleteBookOffer(String username, int bookId) {
        UserProfile userProfile = userProfileDAO.findByUsername(username)
                .orElseThrow(() -> new IllegalStateException("This user profile does not exist in the Database"));
        Book book = bookDAO.findByBookId(bookId)
                .orElseThrow(() -> new IllegalStateException("This book does not exist in the Database"));
        userProfileDAO.save(userProfile);
        bookDAO.delete(book);
    }

    @Override
    @Transactional
    public void deleteBookRequest(String username, int bookId) {
        UserProfile userProfile = userProfileDAO.findByUsername(username)
                .orElseThrow(() -> new IllegalStateException("User profile does not exist"));
        Book book = bookDAO.findById(bookId)
                .orElseThrow(() -> new IllegalStateException("Book does not exist"));
        if (!book.getRequestingUsers().remove(userProfile)) {
            throw new IllegalStateException("User not found in book's requesting users list.");
        }
        bookDAO.save(book);
    }

    @Override
    public List<BookFormData> searchBooks(SearchFormData searchFormData) {
        return searchFactory.getStrategy(searchFormData).search(searchFormData,bookDAO);
    }

    @Override
    public List<BookFormData> recommendBooks(String username, RecommendationsFormData recommendationsFormData) {
        List<Book> resultsBook = new ArrayList<>();
        resultsBook = recommendationsFactory.getRecommendationStrategy(recommendationsFormData).recommend(recommendationsFormData,bookDAO);
        List<BookFormData> resultsFormData = new ArrayList<>();
        for (Book book: resultsBook){
            resultsFormData.add(convertToBookFormData(book));
        }
        return resultsFormData;
    }

    @Transactional
    public void acceptBookRequest(String owner,String selectedUsername, int bookId) {
        Book book = bookDAO.findById(bookId)
                .orElseThrow(() -> new IllegalStateException("Book not found"));

        List<UserProfile> allRequesters = new ArrayList<>(book.getRequestingUsers());
        UserProfile selectedUser = userProfileDAO.findByUsername(selectedUsername)
                .orElseThrow(() -> new IllegalStateException("User not found"));
        for (UserProfile userProfile: allRequesters){
            List<String> notifications = userProfile.getNotifications();
            if (userProfile.getUsername().equals(selectedUser.getUsername())){
                notifications.add(0,"You have been selected to receive the book: " + book.getTitle());
            }else {
                notifications.add(0,"Book " + book.getTitle() + " has been taken by another user.");
            }
            userProfileDAO.save(userProfile);
        }
        deleteBookOffer(owner,bookId);
    }

    public Book convertToBook(BookFormData bookFormData) {
        Book book = new Book();
        book.setBookId(bookFormData.getBookId());
        book.setTitle(bookFormData.getTitle());
        book.setSummary(bookFormData.getSummary());

        // Handle BookAuthors
        List<BookAuthor> authors = new ArrayList<>();
        for (String name : bookFormData.getBookAuthors()) {
            List<BookAuthor> foundAuthors = bookAuthorDAO.findByName(name).orElseGet(ArrayList::new);
            if (foundAuthors.isEmpty()) {
                BookAuthor newAuthor = new BookAuthor();
                newAuthor.setName(name);
                authors.add(bookAuthorDAO.save(newAuthor));
            } else {
                authors.addAll(foundAuthors);
            }
        }
        book.setBookAuthors(authors);

        List<BookCategory> categories = new ArrayList<>();
        List<BookCategory> foundCategories = bookCategoryDAO.findByName(bookFormData.getBookCategory()).orElseGet(ArrayList::new);
        if (foundCategories.isEmpty()) {
            BookCategory newCategory = new BookCategory();
            newCategory.setName(bookFormData.getBookCategory());
            categories.add(bookCategoryDAO.save(newCategory));
        } else {
            categories.addAll(foundCategories);
        }
        book.setBookCategory(categories.get(0));
        return book;
    }

    public BookFormData convertToBookFormData(Book book) {
        BookFormData bookFormData = new BookFormData();
        bookFormData.setBookId(book.getBookId());
        bookFormData.setTitle(book.getTitle());
        bookFormData.setSummary(book.getSummary());

        List<String> authorNames = book.getBookAuthors().stream()
                .map(BookAuthor::getName)
                .collect(Collectors.toList());
        bookFormData.setBookAuthors(authorNames);

        // Convert BookCategory object to name
        if (book.getBookCategory() != null) {
            bookFormData.setBookCategory(book.getBookCategory().getName());
        }
        bookFormData.setBookAuthors(authorNames);


        return bookFormData;
    }

    public UserProfileFormData convertToUserProfileFormData(UserProfile userProfile) {
        UserProfileFormData formData = new UserProfileFormData();

        formData.setUsername(userProfile.getUsername());
        formData.setFullName(userProfile.getFullName());
        formData.setAge(userProfile.getAge());
        formData.setAddress(userProfile.getAddress());
        formData.setPhoneNumber(userProfile.getPhoneNumber());
        formData.setNotifications(userProfile.getNotifications());

        if (userProfile.getFavouriteBookAuthors() != null) {
            List<String> authorNames = userProfile.getFavouriteBookAuthors().stream()
                    .map(BookAuthor::getName)
                    .collect(Collectors.toList());
            formData.setFavouriteBookAuthors(authorNames);
        }
        if (userProfile.getFavouriteBookCategories() != null) {
            List<String> categoryNames = userProfile.getFavouriteBookCategories().stream()
                    .map(BookCategory::getName)
                    .collect(Collectors.toList());
            formData.setFavouriteBookCategories(categoryNames);
        }
        List<String> bookOffers = userProfile.getBookOffers().stream()
                .map(Book::getTitle)
                .collect(Collectors.toList());

        formData.setBookOffers(bookOffers);
        return formData;
    }

    @Override
    public Book retrieveBook(int bookId){
        Book book = bookDAO.findById(bookId)
                .orElseThrow(() -> new IllegalStateException("Book not found"));
        return book;
    }


}
