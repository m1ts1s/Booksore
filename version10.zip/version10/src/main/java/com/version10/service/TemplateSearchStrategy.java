package com.version10.service;

import com.version10.dao.BookDAO;
import com.version10.domain.Book;
import com.version10.domain.BookAuthor;
import com.version10.domain.UserProfile;
import com.version10.formsdata.BookFormData;
import com.version10.formsdata.SearchFormData;
import com.version10.formsdata.UserProfileFormData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Component
public abstract class TemplateSearchStrategy implements SearchStrategy{
    @Autowired
    protected BookDAO bookDAO;

    public List<BookFormData> search(SearchFormData searchFormData, BookDAO bookDAO){
        setBookDAO(bookDAO);
        List<Book> searchResult = makeInitialListOfBooks(searchFormData);
        List<BookFormData> results = new ArrayList<>();
        for (Book book: searchResult){
            results.add(convertToBookFormData(book));
        }
        return results;
    }

    public abstract List<Book> makeInitialListOfBooks(SearchFormData searchFormData);

    public abstract boolean checkIfAuthorMatch(SearchFormData searchFormData, Book book);

    public BookFormData convertToBookFormData(Book book) {
        BookFormData bookFormData = new BookFormData();

        bookFormData.setBookId(book.getBookId());
        bookFormData.setTitle(book.getTitle());
        bookFormData.setSummary(book.getSummary());

        // Convert BookCategory object to name
        if (book.getBookCategory() != null) {
            bookFormData.setBookCategory(book.getBookCategory().getName());
        }

        // Convert BookAuthor objects to names
        List<String> authorNames = book.getBookAuthors().stream()
                .map(BookAuthor::getName)
                .collect(Collectors.toList());
        bookFormData.setBookAuthors(authorNames);

        return bookFormData;
    }

    public void setBookDAO(BookDAO bookDAO){
        this.bookDAO = bookDAO;
    }
}
