package com.version10.service;

import com.version10.formsdata.SearchFormData;
import org.springframework.stereotype.Component;

@Component
public class SearchFactory {

    public TemplateSearchStrategy getStrategy(SearchFormData searchFormData){
        if (searchFormData.isExactSearch())
            return new ExactSearchStrategy();
        return new ApproximateSearchStrategy();
    }
}
