package com.version10.service;

import com.version10.domain.UserProfile;
import com.version10.domain.Book;
import com.version10.formsdata.*;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Service
public interface UserProfileService {
    public UserProfileFormData retrieveProfile(String username);

    public void save(UserProfileFormData userProfileFormData);

    public List<BookFormData> retrieveBookOffers(String username);
    public void addBookOffer(String username, BookFormData bookFormData);

    public List<BookFormData> searchBooks(SearchFormData searchFormData);

    public List<BookFormData> recommendBooks(String username, RecommendationsFormData recommendationsFormData);

    public void requestBook(int bookId, String username);

    public List<BookFormData> retrieveBookRequests(String username);

    public List<UserProfileFormData> retrieveRequestingUsers(int bookId);

    public void deleteBookOffer(String username, int bookId);

    public void deleteBookRequest(String username, int bookId);

    public void acceptBookRequest(String owner,String username, int bookId);

    public Book retrieveBook(int bookId);

}
