package com.version10.service;

import com.version10.dao.BookDAO;
import com.version10.domain.Book;
import com.version10.domain.BookAuthor;
import com.version10.formsdata.RecommendationsFormData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
@Component
public class RecommendByAuthors extends TemplateRecommendStrategy{
    @Override
    public List<Book> makeRecommendations(RecommendationsFormData recommendationsFormData) {
        List<Book> allBooks = bookDAO.findAll();
        List<Book> results = new ArrayList<>();
        for(Book book : allBooks){
            List<String> authorNames = new ArrayList<>();
            for(BookAuthor bookAuthor: book.getBookAuthors()){
                authorNames.add(bookAuthor.getName());
            }
            for(String author: recommendationsFormData.getAuthors()){
                if(authorNames.contains(author)){
                    results.add(book);
                }
            }
        }
        return results;
    }

}
