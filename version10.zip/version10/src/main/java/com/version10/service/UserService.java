package com.version10.service;

import com.version10.domain.User;
import org.springframework.stereotype.Service;

@Service
public interface UserService {
    public void saveUser(User user);
    public boolean isUserPresent(User user);
    public User findByUsername(String username);
}
