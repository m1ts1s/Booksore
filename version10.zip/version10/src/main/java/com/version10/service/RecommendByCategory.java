package com.version10.service;

import com.version10.dao.BookDAO;
import com.version10.domain.Book;
import com.version10.formsdata.RecommendationsFormData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
@Component
public class RecommendByCategory extends TemplateRecommendStrategy{

    @Override
    public List<Book> makeRecommendations(RecommendationsFormData recommendationsFormData) {
        List<Book> result = new ArrayList<>();
        List<Book> allBooks = bookDAO.findAll();
        for (Book book : allBooks){
            if(recommendationsFormData.getCategories().contains(book.getBookCategory().getName())){
                result.add(book);
            }
        }
        return result;
    }

}
