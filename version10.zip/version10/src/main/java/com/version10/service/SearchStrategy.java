package com.version10.service;

import com.version10.dao.BookDAO;
import com.version10.formsdata.BookFormData;
import com.version10.formsdata.SearchFormData;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public interface SearchStrategy {
    List<BookFormData> search(SearchFormData query, BookDAO bookDAO);
}
