package com.version10.service;

import com.version10.dao.BookDAO;
import com.version10.domain.Book;
import com.version10.formsdata.BookFormData;
import com.version10.formsdata.RecommendationsFormData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
@Component
public abstract class TemplateRecommendStrategy {
    @Autowired
    protected BookDAO bookDAO;

    public List<Book> recommend(RecommendationsFormData recommendationsFormData, BookDAO bookDAO){
        setBookDAO(bookDAO);
        List<Book> results = makeRecommendations(recommendationsFormData);
        return results;
    }

    public abstract List<Book> makeRecommendations(RecommendationsFormData recommendationsFormData);

    public void setBookDAO(BookDAO bookDAO){
        this.bookDAO = bookDAO;
    }
}
