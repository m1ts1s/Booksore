package com.version10.formsdata;

import java.util.List;

public class BookFormData {
    private int bookId;
    private String title;
    private List<String> bookAuthors;
    private String bookCategory;
    private String summary;
    private List<String> requestingUsers;
    private String userProfile;
    public BookFormData() {
    }
    public BookFormData(int bookId, String title, List<String> bookAuthors, String bookCategory, String summary) {
        this.bookId = bookId;
        this.title = title;
        this.bookAuthors = bookAuthors;
        this.bookCategory = bookCategory;
        this.summary = summary;
    }

    public BookFormData(String title, List<String> bookAuthors, String bookCategory, String summary) {
        this.title = title;
        this.bookAuthors = bookAuthors;
        this.bookCategory = bookCategory;
        this.summary = summary;
    }

    // Getters and setters
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public List<String> getBookAuthors() {
        return bookAuthors;
    }

    public void setBookAuthors(List<String> bookAuthors) {
        this.bookAuthors = bookAuthors;
    }

    public String getBookCategory() {
        return bookCategory;
    }

    public void setBookCategory(String bookCategory) {
        this.bookCategory = bookCategory;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    public List<String> getRequestingUsers() {
        return requestingUsers;
    }

    public void setRequestingUsers(List<String> requestingUsers) {
        this.requestingUsers = requestingUsers;
    }

    public String getUserProfile() {
        return userProfile;
    }

    public void setUserProfile(String userProfile) {
        this.userProfile = userProfile;
    }

}
