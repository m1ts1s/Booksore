package com.version10.formsdata;

import java.util.List;

public class SearchFormData {
    private String queryTitle;

    private String queryAuthor;

    private boolean exactSearch;

    public SearchFormData() {
    }

    public String getQueryTitle() {
        return queryTitle;
    }

    public void setQueryTitle(String queryTitle) {
        this.queryTitle = queryTitle;
    }

    public String getQueryAuthor() {
        return queryAuthor;
    }

    public void setQueryAuthor(String queryAuthor) {
        this.queryAuthor = queryAuthor;
    }

    public boolean isExactSearch() {
        return exactSearch;
    }

    public void setExactSearch(boolean exactSearch) {
        this.exactSearch = exactSearch;
    }
}
