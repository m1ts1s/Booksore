package com.version10.formsdata;

import java.util.ArrayList;
import java.util.List;

public class UserProfileFormData {
        private String username;
        private String fullName;
        private int age;
        private List<String> favouriteBookAuthors;
        private List<String> favouriteBookCategories;
        private List<String> bookOffers;

        private String address;

        private String phoneNumber;

        private List<String> notifications = new ArrayList<>();

    public List<String> getNotifications() {
        return notifications;
    }

    public void setNotifications(List<String> notifications) {
        this.notifications = notifications;
    }

    public UserProfileFormData() {
        // Default constructor
    }

    public UserProfileFormData(String username, String fullName, int age, List<String> favouriteBookAuthors, List<String> favouriteBookCategories, List<String> bookOffers, String address, String phoneNumber) {
        this.username = username;
        this.fullName = fullName;
        this.age = age;
        this.favouriteBookAuthors = favouriteBookAuthors;
        this.favouriteBookCategories = favouriteBookCategories;
        this.bookOffers = bookOffers;
        this.address = address;
        this.phoneNumber = phoneNumber;
    }

    // Getters and setters
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public List<String> getFavouriteBookAuthors() {
        return favouriteBookAuthors;
    }

    public void setFavouriteBookAuthors(List<String> favouriteBookAuthors) {
        this.favouriteBookAuthors = favouriteBookAuthors;
    }

    public List<String> getFavouriteBookCategories() {
        return favouriteBookCategories;
    }

    public void setFavouriteBookCategories(List<String> favouriteBookCategories) {
        this.favouriteBookCategories = favouriteBookCategories;
    }

    public List<String> getBookOffers() {
        return bookOffers;
    }

    public void setBookOffers(List<String> bookOffers) {
        this.bookOffers = bookOffers;
    }


    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

}

