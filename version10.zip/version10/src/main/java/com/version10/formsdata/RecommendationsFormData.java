package com.version10.formsdata;

import java.util.List;

public class RecommendationsFormData {

    public enum RecommendationType {
        CATEGORY, AUTHOR, BOTH
    }
    private RecommendationType recommendationType;
    private List<String> categories;

    private List<String> authors;



    // Constructors, getters, and setters
    public RecommendationType getRecommendationType() {
        return recommendationType;
    }

    public void setRecommendationType(RecommendationType recommendationType) {
        this.recommendationType = recommendationType;
    }

    public List<String> getCategories() {
        return categories;
    }

    public void setCategories(List<String> categories) {
        this.categories = categories;
    }

    public List<String> getAuthors() {
        return authors;
    }

    public void setAuthors(List<String> authors) {
        this.authors = authors;
    }


}
