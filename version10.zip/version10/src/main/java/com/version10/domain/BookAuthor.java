package com.version10.domain;

import jakarta.persistence.*;

import java.util.List;
@Entity
@Table(name = "BookAuthor")
public class BookAuthor {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "authorId")
    private int authorId;
    @Column(name = "name")
    private String name;
    @ManyToMany(mappedBy = "bookAuthors")
    private List<Book> books;

    public BookAuthor() {
    }

    public BookAuthor(int authorId, String name, List<Book> books) {
        this.authorId = authorId;
        this.name = name;
        this.books = books;
    }

    public BookAuthor(String name, List<Book> books) {
        this.name = name;
        this.books = books;
    }

    public int getAuthorId() {
        return authorId;
    }

    public void setAuthorId(int authorId) {
        this.authorId = authorId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Book> getBooks() {
        return books;
    }

    public void setBooks(List<Book> books) {
        this.books = books;
    }

    @Override
    public String toString() {
        return "BookAuthor{" +
                "name='" + name + '\'' +
                ", books=" + books +
                '}';
    }
}