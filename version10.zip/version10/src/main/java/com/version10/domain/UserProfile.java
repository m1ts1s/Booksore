package com.version10.domain;

import com.version10.formsdata.UserProfileFormData;
import jakarta.persistence.*;

import java.util.List;
@Entity
@Table(name = "user_profile")
public class UserProfile {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "profileId")
    private int profile_id;

    @Column(name = "username", unique = true, nullable = false)
    private String username;

    @Column(name="fullName")
    private String fullName;

    @Column(name="age")
    private int age;

    @Column
    private String address;

    @Column
    private String phoneNumber;


    @ManyToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinTable(
            name = "user_favorite_authors",
            joinColumns = {@JoinColumn(name = "profileId", referencedColumnName = "profileId")},
            inverseJoinColumns = {@JoinColumn(name = "authorId", referencedColumnName = "authorId")}
    )
    private List<BookAuthor> favouriteBookAuthors;


    @ManyToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinTable(
            name = "user_favorite_categories",
            joinColumns = {@JoinColumn(name = "profileId", referencedColumnName = "profileId")},
            inverseJoinColumns = {@JoinColumn(name = "categoryId", referencedColumnName = "categoryId")}
    )
    private List<BookCategory> favouriteBookCategories;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "offered_by_user_id")
    private List<Book> bookOffers;
    @ElementCollection
    @CollectionTable(name="notifications_table", joinColumns=@JoinColumn(name="entity_id"))
    @Column(name="notification")
    private List<String> notifications;


    public UserProfile() {
    }

    public UserProfile(String username, String fullName, int age, List<BookAuthor> favouriteBookAuthors, List<BookCategory> favouriteBookCategories, List<Book> bookOffers) {
        this.username = username;
        this.fullName = fullName;
        this.age = age;
        this.favouriteBookAuthors = favouriteBookAuthors;
        this.favouriteBookCategories = favouriteBookCategories;
        this.bookOffers = bookOffers;
    }

    public UserProfile(String username, String fullName, int age, List<BookAuthor> favouriteBookAuthors, List<BookCategory> favouriteBookCategories, List<Book> bookOffers, String address, String phoneNumber) {
        this.username = username;
        this.fullName = fullName;
        this.age = age;
        this.favouriteBookAuthors = favouriteBookAuthors;
        this.favouriteBookCategories = favouriteBookCategories;
        this.bookOffers = bookOffers;
        this.address = address;
        this.phoneNumber = phoneNumber;
    }

    public UserProfile(String username, String fullName, int age) {
        this.username = username;
        this.fullName = fullName;
        this.age = age;
    }

    public int getProfileId() {
        return profile_id;
    }

    public void setProfileId(int profile_id) {
        this.profile_id = profile_id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public List<BookAuthor> getFavouriteBookAuthors() {
        return favouriteBookAuthors;
    }

    public void setFavouriteBookAuthors(List<BookAuthor> favouriteBookAuthors) {
        this.favouriteBookAuthors = favouriteBookAuthors;
    }

    public List<BookCategory> getFavouriteBookCategories() {
        return favouriteBookCategories;
    }

    public void setFavouriteBookCategories(List<BookCategory> favouriteBookCategories) {
        this.favouriteBookCategories = favouriteBookCategories;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public List<Book> getBookOffers() {
        return bookOffers;
    }

    public void setBookOffers(List<Book> bookOffers) {
        this.bookOffers = bookOffers;
    }

    public List<String> getNotifications() {
        return notifications;
    }

    public void setNotifications(List<String> notifications) {
        this.notifications = notifications;
    }

    @Override
    public String toString() {
        return "UserProfile{" +
                "username='" + username + '\'' +
                ", fullName='" + fullName + '\'' +
                ", age=" + age +
                ", favouriteBookAuthors=" + favouriteBookAuthors +
                ", favouriteBookCategories=" + favouriteBookCategories +
                ", bookOffers=" + bookOffers +
                '}';
    }

}