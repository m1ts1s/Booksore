package com.version10.domain;

import jakarta.persistence.*;

import java.util.List;
import java.util.Set;

@Entity
@Table(name = "book")
public class Book {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "bookId")
    private int bookId;

    @Column(name = "title")
    private String title;

    @Column(name = "summary")
    private String summary;

    @ManyToMany
    @JoinTable(
            name = "book_authors",
            joinColumns = @JoinColumn(name = "bookId"),
            inverseJoinColumns = @JoinColumn(name = "authorId")
    )
    private List<BookAuthor> bookAuthors;


    @ManyToOne
    @JoinColumn(name = "bookCategoryId")
    private BookCategory bookCategory;

    @ManyToMany
    @JoinTable(
            name = "book_requests",
            joinColumns = @JoinColumn(name = "bookId"),
            inverseJoinColumns = @JoinColumn(name = "profileId")
    )
    private List<UserProfile> requestingUsers;

    public Book() {
    }

    public Book(int bookId, String title, List<BookAuthor> bookAuthors, BookCategory bookCategory, List<UserProfile> requestingUsers) {
        this.bookId = bookId;
        this.title = title;
        this.bookAuthors = bookAuthors;
        this.bookCategory = bookCategory;
        this.requestingUsers = requestingUsers;
    }

    public Book(String title, List<BookAuthor> bookAuthors, BookCategory bookCategory) {
        this.title = title;
        this.bookAuthors = bookAuthors;
        this.bookCategory = bookCategory;
    }

    public Book(String title, List<BookAuthor> bookAuthors, BookCategory bookCategory, String summary) {
        this.title = title;
        this.bookAuthors = bookAuthors;
        this.bookCategory = bookCategory;
        this.summary = summary;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public int getBookId() {
        return bookId;
    }

    public String getTitle() {
        return title;
    }

    public List<BookAuthor> getBookAuthors() {
        return bookAuthors;
    }

    public BookCategory getBookCategory() {
        return bookCategory;
    }

    public List<UserProfile> getRequestingUsers() {
        return requestingUsers;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setBookAuthors(List<BookAuthor> bookAuthors) {
        this.bookAuthors = bookAuthors;
    }

    public void setBookCategory(BookCategory bookCategory) {
        this.bookCategory = bookCategory;
    }

    public void setRequestingUsers(List<UserProfile> requestingUsers) {
        this.requestingUsers = requestingUsers;
    }

    @Override
    public String toString() {
        return "Book{" +
                "title='" + title + '\'' +
                ", bookAuthors=" + bookAuthors +
                ", bookCategory=" + bookCategory +
                '}';
    }

}