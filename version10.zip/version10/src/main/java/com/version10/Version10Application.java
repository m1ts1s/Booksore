package com.version10;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Version10Application {

	public static void main(String[] args) {
		SpringApplication.run(Version10Application.class, args);
	}

}
