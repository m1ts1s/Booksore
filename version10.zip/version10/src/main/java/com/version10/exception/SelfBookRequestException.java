package com.version10.exception;

public class SelfBookRequestException extends RuntimeException {
    public SelfBookRequestException(String message) {
        super(message);
    }
}