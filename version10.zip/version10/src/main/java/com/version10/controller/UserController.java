package com.version10.controller;

import com.version10.domain.Book;
import com.version10.domain.UserProfile;
import com.version10.exception.SelfBookRequestException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import com.version10.formsdata.*;
import com.version10.service.UserProfileService;
import com.version10.service.UserService;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.ArrayList;
import java.util.List;

@Controller
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private UserProfileService userProfileService;

    @RequestMapping("/menu")
    public String getUserMainMenu() {
        return "mainMenu";
    }

    @RequestMapping("/viewProfile")
    public String retrieveProfile(Model model) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String username = auth.getName();
        UserProfileFormData userProfile = userProfileService.retrieveProfile(username);
        model.addAttribute("userProfile", userProfile);
        return "viewProfile";
    }

    @RequestMapping("/profile")
    public String getProfileMenu(){
        return "profileMenu";
    }

    @RequestMapping("/createProfile")
    public String createProfile(Model model) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        if (userProfileService.retrieveProfile(username) != null)
            return "profileExisting";
        model.addAttribute("userProfileFormData", new UserProfileFormData());
        return "createProfile";
    }

    @PostMapping("/saveProfile")
    public String saveProfile(@ModelAttribute("userProfileFormData") UserProfileFormData userProfileFormData, Model model) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentUsername = authentication.getName();
        userProfileFormData.setUsername(currentUsername);
        userProfileService.save(userProfileFormData);
        model.addAttribute("userProfile", userProfileFormData);
        return "profileMenu";
    }


    @RequestMapping("/showRequesters")
    public String showRequesters(Model model) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        List<BookFormData> bookOffers = userProfileService.retrieveBookOffers(username);
        model.addAttribute("bookOffers", bookOffers);
        model.addAttribute("username", username);
        return "viewRequestedBookOffers";  // Thymeleaf template name for showing book offers
    }


    @RequestMapping("/offerForm")
    public String showOfferForm(Model model) {
        model.addAttribute("bookForm", new BookFormData());
        return "offerForm";
    }

    @RequestMapping("/listBookOffers")
    public String listBookOffers(Model model) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        List<BookFormData> bookOffers = userProfileService.retrieveBookOffers(username);
        model.addAttribute("bookOffers", userProfileService.retrieveBookOffers(username));
        model.addAttribute("username",username);
        return "offerList";
    }

    @RequestMapping(value = "/saveOffer", method = RequestMethod.POST)
    public String saveOffer(@ModelAttribute("bookForm") BookFormData bookFormData, Model model) {
        try {
            Authentication auth = SecurityContextHolder.getContext().getAuthentication();
            String username = auth.getName();  // Retrieve the username from security context

            userProfileService.addBookOffer(username, bookFormData);
            model.addAttribute("successMessage", "Book offer added successfully!");

        } catch (Exception e) {
            model.addAttribute("errorMessage", "Error adding book offer: " + e.getMessage());
           return "offerForm";  // Stay on the form page if there's an error
        }
        return "redirect:/listBookOffers";  // Redirect to avoid double posting
    }

    @RequestMapping("/searchForm")
    public String showSearchForm(Model model) {
        model.addAttribute("searchForm", new SearchFormData());
        return "searchForm";
    }

    @RequestMapping("/search")
    public String search(SearchFormData searchFormData, Model model) {
        List<BookFormData> searchResults = userProfileService.searchBooks(searchFormData);
        model.addAttribute("searchResults", searchResults);
        if(searchResults.isEmpty()){
            return "noResults";
        }
        return "searchResults";
    }

    @RequestMapping("/showRecommendationsForm")
    public String showRecommendationsForm(Model model) {
        return "recommendationForm";
    }

    @RequestMapping("/recommendBooks")
    public String recommendBooks(RecommendationsFormData recomFormData, Model model) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        UserProfileFormData userFormData = userProfileService.retrieveProfile(username);
        recomFormData.setAuthors(userFormData.getFavouriteBookAuthors());
        recomFormData.setCategories(userFormData.getFavouriteBookCategories());
        List<BookFormData> results = userProfileService.recommendBooks(username, recomFormData);
        model.addAttribute("recommendations", results);
        if (results.isEmpty()){
            return "noResults";
        }
        return "recommendations";
    }


    @RequestMapping("/requestBook/{bookId}")
    public String requestBook(@PathVariable("bookId") int bookId, Model attribute) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentUsername = authentication.getName();
        try {
            userProfileService.requestBook(bookId,currentUsername);
            attribute.addAttribute("message", "Book request submitted successfully.");
        } catch (SelfBookRequestException e) {
            attribute.addAttribute("error", e.getMessage());
        } catch (IllegalStateException e) {
            attribute.addAttribute("error2", "Error! Something went wrong... Try again later.");
        }
        return "requestResults";
    }

    @RequestMapping("/showUserBookRequests")
    public String showUserBookRequests(Model model){
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName(); // Current user's username

        // Retrieve books that this user has requested from others
        List<BookFormData> requestedBooks = userProfileService.retrieveBookRequests(username);
        model.addAttribute("requestedBooks", requestedBooks);
        UserProfileFormData user = userProfileService.retrieveProfile(username);
        model.addAttribute("username", username);

        return "viewUserBookRequests"; // Ensure this template is set up to display requested books
    }

    @RequestMapping("/viewUserNotifications")
    public String showUserNotifications(Model model){
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName(); // Current user's username
        UserProfileFormData userProfile = userProfileService.retrieveProfile(username);
        model.addAttribute("userProfile", userProfile);
        return "viewUserNotifications"; // Ensure this template is set up to display requested books
    }

    @RequestMapping("/requestingUsersForBookOffer/{bookId}")
    public String showRequestingUsersForBookOffer(@PathVariable("bookId") int bookId, Model model) {
        List<UserProfileFormData> requestingUsers = userProfileService.retrieveRequestingUsers(bookId);
        String bookTitle = userProfileService.retrieveBook(bookId).getTitle();
        model.addAttribute("bookTitle", bookTitle);
        model.addAttribute("requestingUsers", requestingUsers);
        return "viewRequestingUsers";
    }


    @RequestMapping("/acceptRequest/{username}/{bookId}")
    public String acceptRequest(@PathVariable("username") String username, @PathVariable("bookId") int bookId, RedirectAttributes redirectAttributes) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String owner = authentication.getName();
        try {
            userProfileService.acceptBookRequest(owner,username, bookId);
            redirectAttributes.addFlashAttribute("success", "Book request accepted successfully and other requesters notified.");
        } catch (IllegalStateException e) {
            redirectAttributes.addFlashAttribute("error", "Error: " + e.getMessage());
        }
        return "viewRequestingUsers";
    }


    @RequestMapping("/deleteBookRequest/{username}/{bookId}")
    public String deleteBookRequest(@PathVariable("username")String username,@PathVariable("bookId") int bookId, Model model) {
        try {
            userProfileService.deleteBookRequest(username, bookId);

            model.addAttribute("success", "Book deletion successful");
        }catch (IllegalStateException e){
            model.addAttribute("error", "Error: " + e.getMessage());
        }
        return "viewUserBookRequests";
    }

    @RequestMapping("/deleteBookOffer/{bookId}")
    public String deleteBookOffer(@PathVariable int bookId, RedirectAttributes redirectAttributes) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName(); // Get the username of the logged-in user.

        try {
            userProfileService.deleteBookOffer(username, bookId);
            List<UserProfileFormData> requestingUsers = userProfileService.retrieveRequestingUsers(bookId);
            for (UserProfileFormData user : requestingUsers) {
                userProfileService.deleteBookRequest(user.getUsername(), bookId);
            }

            redirectAttributes.addFlashAttribute("successMessage", "Book offer and all associated requests have been successfully removed.");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error occurred while deleting the book offer.");
        }
        return "redirect:/listBookOffers";
    }
}
