package com.version10.dao;

import com.version10.domain.BookCategory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
@Repository
public interface BookCategoryDAO extends JpaRepository<BookCategory, Integer> {
    Optional<List<BookCategory>> findByName(String name);
}
