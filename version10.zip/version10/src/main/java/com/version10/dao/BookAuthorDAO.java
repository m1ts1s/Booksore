package com.version10.dao;

import com.version10.domain.BookAuthor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
@Repository
public interface BookAuthorDAO extends JpaRepository<BookAuthor, Integer> {
    Optional<List<BookAuthor>> findByName(String name);
}
