package com.version10.dao;

import com.version10.domain.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
@Repository
public interface BookDAO extends JpaRepository<Book, Integer> {

    Optional<List<Book>> findByTitle(String title);

    Optional<List<Book>> findByTitleContaining(String title);

    Optional<Book> findByBookId(int id);
}
