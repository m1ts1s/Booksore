package com.version10.dao;

import com.version10.domain.UserProfile;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
@Repository
public interface UserProfileDAO extends JpaRepository<UserProfile, String> {
    Optional<UserProfile> findByUsername(String username);
}
